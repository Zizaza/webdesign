<?php
/**
* Module Smooth Gallery For Joomla 1.5.x
* Version		: 1.5.001
* Created by	: Joomlaplates & http://smoothgallery.jondesign.net/
* Email			: support@joomlaplates.net
* Created on	: 15 July 2010
* Las Modified 	: 15 July 2010
*
* URL			: www.joomlaplates.net
* License GPLv2.0 - http://www.gnu.org/licenses/gpl-2.0.html
* Based on jquery(http://www.jquery.com) and interface element (http://interface.eyecon.ro)
*/

// no direct access
defined('_JEXEC') or die;

?>
<div>
	<div id="myGallery" style="width: <?php echo $slidewidth;?>px; height: <?php echo $slideheight;?>px;">
    		<?php for ($i=0; $i<= $maxImages; $i++): ?>
				<?php if ( trim($params->get('image_status_'.$i,'0')) && trim($params->get('slide_img'.$i,'')) ) { ?>
                <div class="imageElement">
                        <h3><?php echo $params->get('image_title'.$i,'');?></h3>
                        <p><?php echo $params->get('image_description'.$i,'');?></p>
                        <a href="<?php echo $params->get('image_url'.$i,'');?>" title="<?php echo $params->get('image_title'.$i,'');?>" class="open"></a>
                        <img src="<?php echo $baseurl?><?php echo $params->get('slide_img'.$i,'');?>" class="full" alt="<?php echo $params->get('image_title'.$i,'');?>" />
                </div>
			<?php } ?>
			<?php endfor; ?>
	</div>

</div>
