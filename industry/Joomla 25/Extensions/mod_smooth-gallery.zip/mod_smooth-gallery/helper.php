<?php
/**
* Module Smooth Gallery For Joomla 1.5.x
* Version		: 1.5.001
* Created by	: Joomlaplates & http://smoothgallery.jondesign.net/
* Email			: support@joomlaplates.net
* Created on	: 15 July 2010
* Las Modified 	: 15 July 2010
* 
* URL			: www.joomlaplates.net
* License GPLv2.0 - http://www.gnu.org/licenses/gpl-2.0.html
* Based on jquery(http://www.jquery.com) and interface element (http://interface.eyecon.ro)
*/

// no direct access
defined('_JEXEC') or die;

require_once (JPATH_SITE.DS.'components'.DS.'com_content'.DS.'helpers'.DS.'route.php');

?>