<?php

/**
* Module Smooth Gallery For Joomla 1.5.x
* Version		: 1.5.001
* Created by	: Joomlaplates & http://smoothgallery.jondesign.net/
* Email			: support@joomlaplates.net
* Created on	: 15 July 2010
* Las Modified 	: 15 July 2010
* 
* URL			: www.joomlaplates.net
* License GPLv2.0 - http://www.gnu.org/licenses/gpl-2.0.html
* Based on jquery(http://www.jquery.com) and interface element (http://interface.eyecon.ro)
*/

defined('_JEXEC') or die;

// Include the syndicate functions only once
require_once (dirname(__FILE__).DS.'helper.php');

$slidewidth 		= $params->get( 'slidewidth' );
$slideheight		= $params->get( 'slideheight' );
$slideduration 		= $params->get( 'slideduration' );
$slidedelay			= $params->get( 'slidedelay' );
$baseurl 			= JURI::base();
$showCaption 		= $params->get( 'showCaption' );
$infozone_height 	= $params->get( 'infozone_height' );
$showthumbs 		= $params->get( 'showthumbs' );
$showthumbs_name 	= $params->get( 'showthumbs_name' );
$links 				= $params->get( 'links' );
$maxImages 			= 10;
$docs = JFactory::getDocument();
$string = ' .slideInfoZone{height:'.$infozone_height.';} '."\r\n";
if ($showCaption == "0"){
	$string .= ' .slideInfoZone{display:none;} '."\r\n";	
} 
if ($showthumbs == "0") {
 	$string .= ' .carouselBtn{display:none;} '."\r\n";
}

$docs->addStyleDeclaration( $string );
									   
JHTML::stylesheet( 'modules/'.$module->module.'/smooth_gallery/jd.gallery.css' );	
JHTML::stylesheet( 'modules/'.$module->module.'/smooth_gallery/layout.css' );	
JHTML::script('modules/'.$module->module.'/smooth_gallery/jd.gallery.js');

require(JModuleHelper::getLayoutPath($module->module));
?>
<script type="text/javascript">
		var myGallery = new gallery($('myGallery'), {
			timed: true,
			embedLinks: <?php echo $links;?>,
			fadeDuration: <?php echo $slideduration;?>,
			delay: <?php echo $slidedelay;?>,
			useThumbGenerator: true,
			textShowCarousel: '<?php echo $showthumbs_name;?>',
			thumbGenerator: '<?php echo $baseurl; ?>modules/mod_jp_smooth_gallery/resizer.php'
		});
</script>
