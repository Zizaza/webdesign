<?php
/**
 * JTouch - Mobile Controller Plugin for Joomla 2.5
 * (c) 2011 - 2012 MobileMeWs.com
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );

class  plgSystemJtouchmobile extends JPlugin {

	/**
	 * Hook to app process, after initialized
	 */
	public function onAfterInitialise(){
		
	}
	
	/**
	 * Hook to the route process, change default template to Jtouch if 
	 * user access from a mobile device. Also redirect to new default home page (in compare with desktop's one)
	 */
	public function onAfterRoute() {
    	$app = &JFactory::getApplication();

	    if ($app->isAdmin()) {
	      return;
	    }
		
	    $enabledJts = (int)$this->params->get('jtouch_mobile_switch_enabled', 0);
	    // Do nothing if this plugin not enable the switcher function
	    if($enabledJts == 0) return;
	    
	    // check for change to desktop template request
	    // If request come from url?
	  	$changeTplRequest = JRequest::getInt('jtpl', 0);
	  	$doChangeReq = false;
		if($changeTplRequest == 0){
			// Check current user session
			$changeTplRequest = $app->getUserStateFromRequest('jtpl', 'jtpl', 0, 'int');
			if($changeTplRequest > 0){
				$doChangeReq = true;
			}else{
				// Check cookie?
				jimport('joomla.utilities.utility');
				$hash = JApplication::getHash('JTOUCHPLUGIN_JTPL');
				$changeTplRequest = JRequest::getInt($hash, 0, 'cookie', JREQUEST_ALLOWRAW | JREQUEST_NOTRIM);
				if($changeTplRequest > 0){
					$doChangeReq = true;
				}
			}
		}else{
			$doChangeReq = true;
		}
		
		$tpl = false;
		if($doChangeReq){
			// Apply this change tpl request
			$forgeJtouch = JRequest::getInt('force', 0);
			if($forgeJtouch == 1){
				$tpl = $this->_getTplFromDataByName('jtouch25');
			}else{
				$tpl = $this->_getTplFromDataById($changeTplRequest);
			}
			
		}else{
			// check for mobile user
		    if ($enabledJts == 1) {
		    	$isMobile = self::isMobileRequest();
		      	if ( $isMobile) {
		        	$mobileTpl = $this->params->get('jtouch_mobile_template', 'jtouch25');
		        	$tpl = $this->_getTplFromDataByName($mobileTpl);
		      	}
		    }
		}
		
		if($tpl){
			// Apply this template
			$this->_setTemplate( $tpl->template );
			$app->getTemplate(true)->params = new JRegistry($tpl->params);
			$app->setUserState('jtpl', $tpl->id);
			
			// Save to cookie
			$config = JFactory::getConfig();
			$cookie_domain = $config->get('cookie_domain', '');
			$cookie_path = $config->get('cookie_path', '/');
			$lifetime = time() + 365 * 24 * 60 * 60;
			setcookie(
				JApplication::getHash('JTOUCHPLUGIN_JTPL'), $tpl->id, $lifetime, $cookie_path, $cookie_domain
			);
		}
		
		// If we are using Jtouch25?
		if($app->getTemplate() == 'jtouch25'){
			// Turn of caching
			$config = &JFactory::getConfig();
			//die(var_dump($config));
			$config->caching = 0;
			
			//Redirect to default page of mobile view?
			$mobileHome = trim($this->params->get('jtouch_default_mobile_menu', '0'));
			if($mobileHome == '-1' || $mobileHome == '0' || $mobileHome == '') return;
			
			$url = clone JFactory::getURI();
			$currentUrl = $url->toString();
			//die($currentUrl);
			if($currentUrl == $url->base() || $currentUrl == $url->base().'index.php'){
				$defaultUrl = $url->base().$mobileHome;
				//die("Location: $defaultUrl");
				header("Cache-Control: no-cache");
				header("Pragma: no-cache");
				header("Location: $defaultUrl");
				jexit();
			}	
		}
	}
	
	
	/**
	 * Hook to the compiler, remove mootools and other scripts
	 * change jtouch scripts to defaults
	 */
	public function onBeforeCompileHead() {
		$app = &JFactory::getApplication();

	    if ($app->isAdmin()) {
	      return;
	    }
	    
		if($app->getTemplate() != 'jtouch25'){
			return;
		}
		$document = JFactory::getDocument();
		//	looking for scripts
		$headers = $document->getHeadData();
		//die(var_dump($headers) );
		
		$isTurnOffJdoc = ((int)$this->params->get('jtouch_mobile_head_off', 0) == 1)? true: false;
		$scripts = isset($headers['scripts']) ? $headers['scripts'] : array();
		$headers['scripts'] = array();
		
		// Change jtouch.jsfile to script file. And may also remove default js cmd files
		foreach($scripts as $url=>$type) {
			//var_dump($type);
			if($type['mime'] == 'jtouch.jsfile'){
				$type['mime'] = 'text/javascript';
				$headers['scripts'][$url] = $type;
			}else if(!$isTurnOffJdoc){
				// Also add Joomla default script file cmd to header!?
				$headers['scripts'][$url] = $type;
			}
		}
		
		// ... for js code
		if($isTurnOffJdoc){
			$headers['script']['text/javascript'] = '';
			if( isset($headers['script']['jtouch.jscode']) ){
				$headers['script']['text/javascript'] = $headers['script']['jtouch.jscode'];
				unset($headers['script']['jtouch.jscode']);	
			}
		}else{
			if( isset($headers['script']['jtouch.jscode']) ){
				$headers['script']['text/javascript'] .= "\n\r\n\r" . $headers['script']['jtouch.jscode'];
				unset($headers['script']['jtouch.jscode']);
			}
		}
		
		// Change jtouch.css file to css cmd, and may also remove default css cmd 
		$css = isset($headers['styleSheets']) ? $headers['styleSheets'] : array();
		$headers['styleSheets'] = array();
		foreach($css as $url=>$type) {
			if($type['mime'] == 'jtouch.cssfile'){
				$type['mime'] = 'text/css';
				$headers['styleSheets'][$url] = $type;
			}else if(!$isTurnOffJdoc){
				$headers['styleSheets'][$url] = $type;
			}
		}
		// ... for css code
		if($isTurnOffJdoc){
			$headers['style']['text/css'] = '';
			if( isset($headers['style']['jtouch.csscode']) ){
				$headers['style']['text/css'] = $headers['style']['jtouch.csscode'];
				unset($headers['style']['jtouch.csscode']);	
			}
		}else{
			if( isset($headers['style']['jtouch.csscode']) ){
				if(!isset($headers['style']['text/css'])) $headers['style']['text/css'] = '';
				$headers['style']['text/css'] .= "\n\r\n\r" . $headers['style']['jtouch.csscode'];
				unset($headers['style']['jtouch.csscode']);
			}
		}
		//die(var_dump($headers));
			
		// Using Jtouch code + native code? Remove Mootools
		if(!$isTurnOffJdoc){
			$scripts = isset($headers['scripts']) ? $headers['scripts'] : array();
			//	cleare the original scripts
			$headers['scripts'] = array();
			//	deleting mootols...
			
			foreach($scripts as $url=>$type) {
				if (strpos($url, 'mootools') === false && strpos($url, 'caption.js') === false && strpos($url, 'js/core.js') === false) {
					$headers['scripts'][$url] = $type;
				}
			}
			//destroy something likes function keepAlive() {
			$headers['script']['text/javascript']  = str_replace('window.addEvent', 'console.log', $headers['script']['text/javascript'] );
		}else{
			// Remove custom code
			$custom = array();
			$custom[] = '   ';
			$headers['custom'] = $custom;
			//$headers['links'] = $custom;
		}
		
		//	set the new head data
		//var_dump($headers); die();
		$document->setHeadData($headers);
	}

	
	/**
	 * Check if users come from mobile devices or not
	 */
	public function isMobileRequest() {
    	$isMobile = false;
    	
    	if(!class_exists('uagent_info')){
    		require_once(JPATH_PLUGINS.DS."system".DS."jtouchmobile".DS."mdetect.php");
    	}
    	$ua = new uagent_info();
    	
    	$isMobile = ( $ua->DetectSmartphone() || $ua->DetectTierTablet() );
    	
    	if((int)$this->params->get('jtouch_mobile_include_tablets', 0) == 0){
    		if($ua->DetectTierTablet() ){
    			$isMobile = false;
    		}	
    	}
    	
    	return $isMobile;
	}
	
	
	/**
	 * Get template info by provide its ID
	 * @param Integer $tplId
	 */
	private function _getTplFromDataById($tplId){
  		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->select('id, template, params');
		$query->from('`#__template_styles`');
		$query->where('`client_id` = 0 AND `id`= '. (int)$tplId);
		$query->order('`id` ASC');
		$db->setQuery( $query );
		$row = $db->loadObject();
		if(!$row){
			return false;
		}else{
			return $row;
		}	
  	}
  	
  
  	/**
  	 * Get template info by provide its name
  	 * @param string $tplName
  	 */
	private function _getTplFromDataByName($tplName){
  		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->select('id, template, params');
		$query->from('`#__template_styles`');
		$query->where('`client_id` = 0 AND `template` LIKE \''.$tplName.'\' ');
		$query->order('`id` ASC');
		$db->setQuery( $query );
		$row = $db->loadObject();
		if(!$row){
			return false;
		}else{
			return $row;
		}	
  	}

  	
  	/**
  	 * Set template that apply to the whole system
  	 * @param object $tpl
  	 */
	protected function _setTemplate( $tpl = null) {
    	if (empty($tpl)) {
      		return;
	    } else {
	    	$app = &JFactory::getApplication();
	      	$app->setTemplate( $tpl);
	
	     	// For sh404SEF
	      	if (!defined('SHMOBILE_MOBILE_TEMPLATE_SWITCHED')) {
	        	define( 'SHMOBILE_MOBILE_TEMPLATE_SWITCHED', 1);
	      	}
	    }
	}
	
}
