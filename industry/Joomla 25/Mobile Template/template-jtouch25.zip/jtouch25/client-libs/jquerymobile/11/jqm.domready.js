// Flag if the message box showed or not
var preventDefaultPageChange = false;

// Flag if the tooks menu created of not
var jtouchToolsCreated = false;

// Flag if assign event to <a> tag
var jouchATagEvent = false;


$(document).bind('pageinit', function(){
	if(jouchATagEvent) return;
	if(jtouchSettings.showLoadingPage == false) return;
	
	jouchATagEvent = true;
	
	$('a').each(function(i, el){
		$(el).click( function(){
			var href = $(this).attr('href');
			//alert(href);
			//console.log(href);
			if(href == null) return;
			if(href[0] == '' || href[0] == '#') return;
						
			//console.log($(el).attr('href'));
			console.log('loading page?');
			$.mobile.showPageLoadingMsg();
			
			setTimeout(function(){$.mobile.hidePageLoadingMsg();}, 3000);
		});
	});
});

/**
 * Check and show message dialog if any
 * @return
 */
$(document).bind('pageshow', function (){
	if(preventDefaultPageChange) {
		//console.log('Dialog created!');
		return;
	}
	// Has Joomla system message? Display as pop-up
    var msgPanel = $('#system-message');
    //console.log(msgPanel);
    if(msgPanel.length > 0){
    	//console.log('should pop up');
    	preventDefaultPageChange = true;
    	$('#hidden_link').simpledialog2({
			'mode' : 'button',
			'headerText' : 'Message',
			'buttonPrompt': msgPanel.html(),
		    'buttons' : {
		    	'OK': {
		         	click: function () {
						// do nothing
		        	}
				}
		    }
		});
    	msgPanel.remove();
    	preventDefaultPageChange=false;
    }
});


/**
 * Make tool tabs page
 * @return
 */
$(document).bind('pageshow', function (){
	if(jtouchToolsCreated){
		//console.log('Tools created!');
		return;
	}else
	
	//console.log('Creating system toolbar');
	jtouchToolsCreated = true;
	
	$('#page-tab-modules').page();
	
	var ctlPage = $('#page-tab-modules').find('h1.tab-module-title');
	//console.log('Number of tools = ' + ctlPage.length);
	if(ctlPage.length == 0) return;
	
	// Create navbar with content get from jtouch-tools position
	var ctlData = '';
	ctlPage.each(function(index){
		var ctlActiveClass = (index == 0)? ' class="ui-btn-active" ' : '';
		ctlData += '<li><a ' + ctlActiveClass +' title="#'+ $(this).attr('title') +'" href="#">' +  $(this).text() + '</a></li>';
	});

	var ctlElement = $('<div></div>', {
		'id':			'page-controll-navbar',
	    'data-role':	'navbar',
	    'html': 		'<ul>'+ ctlData +'</ul>'
	})
	.appendTo('#page-tools-navbar')
	.navbar();
	
	// Fade tab content on click
	var tabContent = null;
	$('#page-controll-navbar a').each(function(i){
		$(this).click(function(e){
			e.preventDefault();
			if(tabContent != null) tabContent.hide();
			tabContent = $($(this).attr('title'));
			$('#page-tools-content').append(tabContent);
			//tabContent.find( ":jqmData(role=listview)" ).listview();

			tabContent.fadeIn('slow');
		});
	});
	
	// Activate first tab
	$('#page-controll-navbar a:first').click();
	
	jtouchToolsCreated = true;
});
