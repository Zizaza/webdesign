// Global setting for Jtouch js
var jtouchSettings = {
		// Show loading box while clicking to a link
		showLoadingPage: true
};

$(document).ready(function(){
	console.log('DOM Ready. Init some pre-jqm load..');
	// Hask checking, fix page not found circle loading 
    var rootAnchor 	= window.location.hash;
    var rootPage	= 'page-' + jtouchPageId;
    if(rootAnchor.length > 0){
    	console.log('hask detected: ' + rootAnchor);
    	if($(rootAnchor).attr('data-role') != 'page'){
	    	console.log('DOM Ready -> Warning: Find no page with ID '+ rootAnchor + ' - Turn to main page ID = #' + rootPage);
	    	location.hash = '#' + rootPage;
	    }
    }
});

$(document).bind("mobileinit", function() {
	console.log('JQM mobileinit loading..');

    $.mobile.page.prototype.options.addBackBtn = true;
    $.mobile.ajaxEnabled = false;
    
    //$.mobile.allowCrossDomainPages = false;
    //$.mobile.linkBindingEnabled = false;
      
    // Note that we recommend disabling this feature if Ajax is disabled or if extensive use of external links are used.
    // http://jquerymobile.com/demos/1.1.0-rc.2/docs/api/globalconfig.html
    $.mobile.pushStateEnabled = false;
    
    //$.mobile.touchOverflowEnabled = true;
    //$.mobile.defaultPageTransition = 'pop';
    
    //$.mobile.hashListeningEnabled = false;
    
    console.log('JQM is grade A browser: ' + $.mobile.gradeA());
});    
