<?php

/**
 * Utils for Jtouch25 template
 * @author huynguyen
 *
 */
class Jtouch25Utils extends JObject {
	public static $tpl = null;

	public static function writeExtraScripts(){
		
	}
	/**
	 * Write all js code to the template,
	 * those must have stype = jtouch.jscode or jtouch.jsfile
	 */
	public static function writeJs($tplParams=null){
		$document = JFactory::getDocument();
		/*
		// Write script files
		if(is_array($document->_scripts)){
			foreach ($document->_scripts as $script=>$settings) {
				if(strtolower($settings['mime']) == 'jtouch.jsfile'){
					echo "\n".'<script src="'.$script.'" type="text/javascript"></script>';
				}
			}
		}
		// Write scripts code
		if (isset($document->_script['jtouch.jscode'])){
			echo "\n".'<script type="text/javascript">' . "\n";
			echo $document->_script['jtouch.jscode'];
			echo "\n". '</script>';
		}
		*/
		if($tplParams != null){
			echo "\n <!-- ReCaptcha Settings -->";
			if( (int)$tplParams->get('jtouch-google-captcha-enable', '1') == 1 ){
				$pubkey = $tplParams->get('jtouch-google-captcha-publickey', '') ;
				$server = 'http://api.recaptcha.net/js/recaptcha_ajax.js';
				/*
				if (JBrowser::getInstance()->isSSLConnection()) {
					$server = 'https://www.google.com/recaptcha/api/js/recaptcha_ajax.js';
				}*/
				echo "\n".'<script src="'.$server.'" type="text/javascript"></script>'."\n";
				echo "<script type='text/javascript'> 
						$('[data-role=page]').live('pageshow', function (event, ui) {
					    	try {
					    		if( $('#dynamic_recaptcha_1').length > 0 ){
					    			Recaptcha.create('{$pubkey}', 'dynamic_recaptcha_1', {theme: 'white'});
					    		}
							}
					    	catch(err){}
					    });
					 </script> "
				;
			}	
		}
	}
	
	/**
	 * Write all css code to the template, those must have stype = jtouch.csscode or jtouch.cssfile 
	 */
	public static function writeCss(){
		/*
		$document = JFactory::getDocument();
		
		// Write css files
		if(is_array($document->_styleSheets)){
			foreach ($document->_styleSheets as $script=>$settings) {
				if(strtolower($settings['mime']) == 'jtouch.cssfile'){
					echo "\n".'<link rel="stylesheet" href="'.$script.'" type="text/css" />';
				}
			}
		}
		// Write css code
		if (isset($document->_style['jtouch.csscode'])){
			echo "\n".'<style type="text/css">'. "\n";
			echo $document->_style['jtouch.csscode'];
			echo "\n".'</style>';
		}
		*/
	}
	
	
	/**
	 * Load stuffs for Virtuemart 2
	 * @param String $assetPath path to VM 2 assets folder (built in Jtouch, not VM's default)
	 */
	public static function vmLoadJsFiles($assetPath, $minfile){
		$document = JFactory::getDocument();
		
		$lang = JFactory::getLanguage();
		$lang->load('com_virtuemart');

		// Main Jtouch css for VM 2
		$document->addStyleSheet($assetPath.'/css/jtouch-virtuemart'.$minfile.'.css', 'jtouch.cssfile');
		$document->addStyleSheet($assetPath.'/css/jtouch-virtuemart-query'.$minfile.'.css', 'jtouch.cssfile');
		
		//jSite()
		$document->addScript($assetPath.'/js/vmsite'.$minfile.'.js', 'jtouch.jsfile');
		
		//jPrice()
		
		$jsVars  = "\n var siteurl = '". JURI::base( ) ."' ;\n" ;
		$jsVars .= " var vmCartText = '". addslashes( JText::_('COM_VIRTUEMART_MINICART_ADDED_JS') )."' ;\n" ;
		$jsVars .= " var vmCartError = '". addslashes( JText::_('COM_VIRTUEMART_MINICART_ERROR_JS') )."' ;\n" ;
		$jsVars .= " var vmCartPopupHeader = '". addslashes( JText::_('JTOUCH25_VM_CART_POPUP_HEADER') )."' ;\n" ;
		$jsVars .= " var vmCartPopupOK = '". addslashes( JText::_('JTOUCH25_VM_CART_POPUP_OK') )."' ;\n" ;
		$jsVars .= " var vmCartPopupViewCart = '". addslashes( JText::_('JTOUCH25_VM_CART_POPUP_VIEWCART') )."' ;\n" ;
		$document->addScriptDeclaration($jsVars, 'jtouch.jscode');
		
		$document->addScript($assetPath.'/js/vmprices.jtouch'.$minfile.'.js', 'jtouch.jsfile');
	}
	
	
	/**
	 * Load stuffs for Kunena forum
	 * @param String $assetPath path to kunena assets folder (built in Jtouch, not Kunena's default)
	 */
	public static function kunenaLoadJsFiles($minfile){
		$document = JFactory::getDocument();
		
		$lang = JFactory::getLanguage();
		$lang->load('com_kunena');

		// Main Jtouch css for Kunena
		$document->addStyleSheet('components/com_kunena/template/jtouch25kunena/css/kunena'.$minfile.'.css', 'jtouch.cssfile');
		$document->addStyleSheet('components/com_kunena/template/jtouch25kunena/css/kunena-query'.$minfile.'.css', 'jtouch.cssfile');
		
		//jSite()
		$document->addScript('components/com_kunena/template/jtouch25kunena/js/kunena'.$minfile.'.js', 'jtouch.jsfile');
	}
	
	/**
	 * Get details of Jtouch25 template, useful for get info about template params
	 */
	public static function getJtouchTemplate(){
		if (!self::$tpl) {
			$db = JFactory::getDbo();
			$query = $db->getQuery(true);
			$query->select('id, template, params');
			$query->from('`#__template_styles`');
			$query->where('`client_id` = 0 AND `template` LIKE \'jtouch25\' ');
			$query->order('`id` ASC');
			$db->setQuery( $query );
			self::$tpl = $db->loadObject();
		}
		return self::$tpl;  		
  	}

}