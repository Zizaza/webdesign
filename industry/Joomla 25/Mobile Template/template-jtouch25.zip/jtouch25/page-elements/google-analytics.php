<?php 
defined('_JEXEC') or die('Restricted access');
?>

<script type="text/javascript">
	$('[data-role=page]').live('pageshow', function (event, ui) {
	    try {
		    console.log('Loading Google Analytics script..');
	    	var _gaq = _gaq || [];
	        _gaq.push(['_setAccount', 		'<?php echo $this->params->get('jtouch-google-account');?>']);
	        _gaq.push(['_setDomainName', 	'<?php echo $this->params->get('jtouch-google-domain');?>']);
	        
	        hash = location.hash;
	
	        if (hash) {
	            _gaq.push(['_trackPageview', hash.substr(1)]);
	        } else {
	            _gaq.push(['_trackPageview']);
	        }
	    } catch(err) {
			console.log('Found some ERRs while loading Google Analytics:');
			console.log(err);
	    }
	
	});
</script>
