
If you need to change some css of Jtouch, just rename this folder from '-customize' to 'customize'
and then add your css code to /customize/template-overwrite.css

Jtouch then find out that you have your own css, and call it without require any hack to the template.