<?php // Access
defined ( '_JEXEC' ) or die ( 'Restricted access' );
?>

<div class="category-view">
	<h2><?php echo JText::_('COM_VIRTUEMART_CATEGORIES') ?> </h2>

	<?php // Start the Output
		foreach ( $this->categories as $category ):
		// Category Link
		$caturl = JRoute::_ ( 'index.php?option=com_virtuemart&view=category&virtuemart_category_id=' . $category->virtuemart_category_id );
	
		// Show Category ?>
		<div class="category floatleft">
			<div class="spacer">
				<a href="<?php echo $caturl ?>" title="<?php echo $category->category_name ?>">
					<?php if (!empty($category->images) ) {
						?>
						<span class="image"><?php echo $category->images[0]->displayMediaThumb("",false); ?></span>
						<?php
					} ?>
					<span class="category-name"><?php echo $category->category_name ?></span>
				</a>
			</div>
		</div>
	<?php
	endforeach; ?>
	<div class="clr"></div>
</div>