<?php 
defined('_JEXEC') or die('Restricted access'); 

foreach ($this->products as $type => $productList ):
	$productTitle = JText::_('COM_VIRTUEMART_'.$type.'_PRODUCT')
?>
<div class="<?php echo $type ?>-view vm-listing">
	<h2><?php echo $productTitle ?></h2>
	<?php // Start the Output
		foreach ( $productList as $product ):
			$link = JRoute::_ ( 'index.php?option=com_virtuemart&view=productdetails&virtuemart_product_id=' . $product->virtuemart_product_id . '&virtuemart_category_id=' . $product->virtuemart_category_id);
		// Show Products ?>
		<div class="product-list">
			<div class="spacer">
				<a href="<?php echo $link; ?>" title="<?php echo  $product->product_name ;?>">
				<div class="image">
					<?php // Product Image
					if ($product->images) {
						echo $product->images[0]->displayMediaThumb( 'class="featuredProductImage" border="0"',false,'class="modal"' );
					}
					?>
				</div>
				<div class="intro">
					<div class="name"><?php echo  $product->product_name ;?></div>
					<div class="description"><?php echo $product->product_s_desc; ?></div>
					<div class="product-price">
						<?php
						if (VmConfig::get ( 'show_prices' ) == '1') { ?>
							<div class="sales-price"><?php echo $this->currency->createPriceDiv( 'salesPrice', '', $product->prices );?></div>
							<div class="discount-price"><?php echo $this->currency->createPriceDiv( 'discountAmount', 'COM_VIRTUEMART_PRODUCT_DISCOUNT_AMOUNT', $product->prices );?></div>
						<?php
								
						//echo $this->currency->createPriceDiv( 'salesPrice', 'COM_VIRTUEMART_PRODUCT_SALESPRICE', $product->prices );
						//echo $this->currency->createPriceDiv( 'salesPriceWithDiscount', 'COM_VIRTUEMART_PRODUCT_SALESPRICE_WITH_DISCOUNT', $product->prices );
						//echo $this->currency->createPriceDiv( 'discountAmount', 'COM_VIRTUEMART_PRODUCT_DISCOUNT_AMOUNT', $product->prices );
						//echo $this->currency->createPriceDiv( 'taxAmount', 'COM_VIRTUEMART_PRODUCT_TAX_AMOUNT', $product->prices );
						} ?>
					</div>
				</div>
				</a>
				<div class="clr"></div>
				
				<?php 
				// Add to cart btn panel?
				require_once JPATH_ROOT.'/templates/jtouch25/utils/jtouch25.utils.php';
				$tpl = Jtouch25Utils::getJtouchTemplate();
				//var_dump($tpl);die();
				$level1Btn = false;
				$pageTheme = 'd';
				if($tpl){
					$tplParams = new JRegistry($tpl->params);
					$level1Btn = ($tplParams->get('jtouch-virtuemart-btn-level1', 0) == 1);
					$pageTheme = $tplParams->get('jtouch-theme', 'd');
				}
				
				if($level1Btn): ?>
				<form method="post" class="product js-recalculate" action="index.php" id="addtocartproduct<?php echo $product->virtuemart_product_id; ?>">
					<div class="addtocart-bar">
						<?php // Add the button
						$button_lbl = JText::_('COM_VIRTUEMART_CART_ADD_TO');
						$button_cls = ''; //$button_cls = 'addtocart_button';
						if (VmConfig::get('check_stock') == '1' && !$product->product_in_stock) {
							$button_lbl = JText::_('COM_VIRTUEMART_CART_NOTIFY');
							$button_cls = 'notify-button';
						} ?>
						<div>
							<div class="width20 floatleft">
								<input type="number" data-mini="true" name="quantity[]" id="quantity-input-slider" class="quantity-input" value="<?php if(isset($product->min_order_level) && (int) $product->min_order_level > 0){echo $product->min_order_level;} else{ echo '1'; } ?>"/>
							</div>
							<div class="width80 floatright addtocart-button">
								<fieldset data-role="controlgroup" data-type="horizontal" data-mini="true" class="floatright tabs">
									<button name="quantity-plus" class="quantity-plus">&nbsp; + &nbsp;</button>
									<button name="cart_minus" class="quantity-minus">&nbsp; - &nbsp;</button>
									<input data-theme='<?php echo $pageTheme;?>' type="submit" name="addtocart"  class="addtocart-button <?php echo $button_cls;?>" value="<?php echo $button_lbl ?>" title="<?php echo $button_lbl ?>" />
								</fieldset>
							</div>
							<div class="clr"></div>
						</div>
					</div>
	
					<?php // Display the add to cart button END ?>
					<input type="hidden" class="pname" value="<?php echo $product->product_name ?>">
					<input type="hidden" name="option" value="com_virtuemart" />
					<input type="hidden" name="view" value="cart" />
					<noscript><input type="hidden" name="task" value="add" /></noscript>
					<input type="hidden" name="virtuemart_product_id[]" value="<?php echo $product->virtuemart_product_id ?>" />
					<?php /** @todo Handle the manufacturer view */ ?>
					<input type="hidden" name="virtuemart_manufacturer_id" value="<?php echo $product->virtuemart_manufacturer_id ?>" />
					<input type="hidden" name="virtuemart_category_id[]" value="<?php echo $product->virtuemart_category_id ?>" />
				</form>	
				<?php 
				endif; // End add to cart btn panel 
				?>
			</div>
			
		</div>
	<?php endforeach; ?>
	<div class="clr"></div>
</div>
<?php endforeach; ?>
