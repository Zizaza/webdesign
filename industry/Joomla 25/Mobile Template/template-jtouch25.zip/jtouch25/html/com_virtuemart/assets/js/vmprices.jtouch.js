
(function($) {
	$.fn.product = function(options) {
		
		this.each(function(){
			var cart = $(this),
			addtocart = cart.find('input.addtocart-button'),
			plus   = cart.find('.quantity-plus'),
			minus  = cart.find('.quantity-minus'),
			select = cart.find('select'),
			radio = cart.find('input:radio'),
			virtuemart_product_id = cart.find('input[name="virtuemart_product_id[]"]').val(),
			quantity = cart.find('.quantity-input');

			addtocart.click(function(e) { 
				sendtocart(cart);
				return false;
			});
			plus.click(function(e) {
				e.preventDefault();
				var Qtt = parseInt(quantity.val());
				if (Qtt != NaN) {
					quantity.val(Qtt + 1);
				}
			});
			minus.click(function(e) {
				e.preventDefault();
				var Qtt = parseInt(quantity.val());
				if (Qtt != NaN && Qtt>1) {
					quantity.val(Qtt - 1);
				}
			});
			select.change(function() {
				$.setproducttype(cart,virtuemart_product_id);
			});
			radio.change(function() {
				$.setproducttype(cart,virtuemart_product_id);
			});
		});


		function sendtocart(form){
			var datas = form.serialize();
			$.getJSON(siteurl+'index.php?option=com_virtuemart&nosef=1view=cart&task=addJS&format=json',encodeURIComponent(datas),
				function(datas, textStatus) {
					if(datas.stat !=0){
						var value = form.find('.quantity-input').val() ;
						var txt = value+" "+form.find(".pname").val()+' '+vmCartText;
						
						$(document).simpledialog2({
							'mode' : 'button',
							'headerText' : vmCartPopupHeader,
							'buttonPrompt': txt,
						    'buttons' : {
						    	'OK': {
						         	click: function () {
										// Cart button effect ;)
										$('#jtouch-tools').addClass('ui-btn-up-e');
										$('#jtouch-tools').fadeTo(2000, 0, function(){
											$('#jtouch-tools').fadeTo(2000, 1);
										});
										return true;
						        	}
								},
							    'Check out now': {
									click: function () { 
										//console.log('On view card');
										if((/iphone|ipod|ipad/gi).test() == false){
											window.location = siteurl + 'index.php?option=com_virtuemart&view=cart';
										}else{
											var a = document.getElementById('hidden_link');
											a.href = siteurl + 'index.php?option=com_virtuemart&view=cart';
											clickEvent = document.createEvent('Event');
											clickEvent.initEvent('click', true, false);
											//console.log(a);
								            a.dispatchEvent(clickEvent);
										}
										
									},
							        icon: "forward",
							        theme: "c"
								}
						    }
						});
					} else {
						var txt = "<H4>"+vmCartError+"</H4>"+datas.msg;
						$(this).simpledialog2({
							'mode' : 'button',
							'buttonPrompt': txt,
						    'headerText' : vmCartPopupHeader,
						    'buttons' : {
						    	'OK': {
						         	click: function () {
						          		//$('#dialogoutput').text($('#dialoglink').attr('data-string'));
						        	}
								}
						    }
						});
					}
					
					if ($(".vmCartModule")[0]) {
						$.ajaxSetup({ cache: false })
						$(".vmCartModule").productUpdate();
					}
				});
		};


	};
	
	$.setproducttype = function(form,id){

		var datas = form.serialize(),
		prices = $("#productPrice"+id);
		prices.fadeTo("fast", 0.75);
		$.getJSON(siteurl+'index.php?option=com_virtuemart&nosef=1&view=productdetails&task=recalculate&format=json',encodeURIComponent(datas),
			function(datas, textStatus) {
				prices.fadeTo("fast", 1);
				// refresh price
				for(key in datas) {
					var value = datas[key];
					if (value!=0) prices.find("span.Price"+key).show().html(value);
					else prices.find(".Price"+key).html(0).hide();
				}
			});
		return false; // prevent reload
	};	
	
	$.fn.productUpdate = function() {
	mod = $(this);
		$.getJSON(siteurl + "index.php?option=com_virtuemart&nosef=1&view=cart&task=viewJS&format=json",
			function(datas, textStatus) {
				if (datas.totalProduct >0) {
					mod.find(".vm_cart_products").html("");
					$.each(datas.products, function(key, val) {
						$("#hiddencontainer .container").clone().appendTo(".vmCartModule .vm_cart_products");
						$.each(val, function(key, val) {
							if ($("#hiddencontainer .container ."+key)) mod.find(".vm_cart_products ."+key+":last").html(val) ;
						});
					});
					mod.find(".total").html(datas.billTotal);
					mod.find(".show_cart").html(datas.cart_show);
				}
				mod.find(".total_products").html(datas.totalProductTxt);
				$.ajaxSetup({ cache: true });
			}
		);
	}
})(jQuery);

jQuery(document).ready(function($) {
//$(document).bind('pagecreate', function (toPage, properties){
	//console.log('ready -> product');
	$(".product").product();

	$("form.js-recalculate").each(function(){
		if ($(this).find(".product-fields").length) {
			var id= $(this).find('input[name="virtuemart_product_id[]"]').val();
			$.setproducttype($(this),id);
		}
	});
});