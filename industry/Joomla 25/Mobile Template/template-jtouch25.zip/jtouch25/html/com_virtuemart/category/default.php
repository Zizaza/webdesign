<?php
/**
*
* Show the products in a category
*
* @package	VirtueMart
* @subpackage
* @author RolandD
* @author Max Milbers
* @author Nguyen @ MobileMeWs.com
* @todo add pagination
* @link http://www.virtuemart.net
* @copyright Copyright (c) 2004 - 2010 VirtueMart Team. All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
* VirtueMart is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* @version $Id: default.php 4819 2011-11-25 12:12:30Z Milbo $
*/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');


$document = JFactory::getDocument();

/*
 * @TODO @Nguyen: Enable search box?
 */
?>
<h1><?php echo $this->category->category_name; ?></h1>
<div class="category_description">
	<?php echo $this->category->category_description ; ?>
</div>

<?php // Start the product list Output
foreach ( $this->products as $product ): ?>
	<div class="product-list">
		<div class="spacer">
			<a href="<?php echo $product->link; ?>" title="<?php echo  $product->product_name ;?>">
			<div class="image">
				<?php
				if ($product->images) {
					echo $product->images[0]->displayMediaThumb( 'class="featuredProductImage" border="0"',false,'class="modal"' );
				}
				?>
			</div>
			<div class="intro">
				<div class="name"><?php echo  $product->product_name ;?></div>
				<div class="description"><?php echo $product->product_s_desc; ?></div>
				<div class="product-price">
					<?php if ($this->show_prices == '1') {
						if( $product->product_unit && VmConfig::get('vm_price_show_packaging_pricelabel')) {
							echo '<strong>'. JText::_('COM_VIRTUEMART_CART_PRICE_PER_UNIT').' ('.$product->product_unit."):</strong>";
						}
						
						if(empty($product->prices) and VmConfig::get('askprice',1) and empty($product->images[0]->file_is_downloadable) ){
							echo JText::_('COM_VIRTUEMART_PRODUCT_ASKPRICE');
						}
					}
					
					if (VmConfig::get ( 'show_prices' ) == '1') { ?>
						<div class="sales-price"><?php echo $this->currency->createPriceDiv( 'salesPrice', '', $product->prices );?></div>
						<div class="discount-price"><?php echo $this->currency->createPriceDiv( 'discountAmount', 'COM_VIRTUEMART_PRODUCT_DISCOUNT_AMOUNT', $product->prices );?></div>
					<?php
							
					/*
					 if( $this->showBasePrice){
						echo $this->currency->createPriceDiv('basePrice','COM_VIRTUEMART_PRODUCT_BASEPRICE',$product->prices);
						echo $this->currency->createPriceDiv('basePriceVariant','COM_VIRTUEMART_PRODUCT_BASEPRICE_VARIANT',$product->prices);
					}
					echo $this->currency->createPriceDiv('variantModification','COM_VIRTUEMART_PRODUCT_VARIANT_MOD',$product->prices);
					echo $this->currency->createPriceDiv('basePriceWithTax','COM_VIRTUEMART_PRODUCT_BASEPRICE_WITHTAX',$product->prices);
					echo $this->currency->createPriceDiv('discountedPriceWithoutTax','COM_VIRTUEMART_PRODUCT_DISCOUNTED_PRICE',$product->prices);
					echo $this->currency->createPriceDiv('salesPriceWithDiscount','COM_VIRTUEMART_PRODUCT_SALESPRICE_WITH_DISCOUNT',$product->prices);
					echo $this->currency->createPriceDiv('salesPrice','COM_VIRTUEMART_PRODUCT_SALESPRICE',$product->prices);
					echo $this->currency->createPriceDiv('priceWithoutTax','COM_VIRTUEMART_PRODUCT_SALESPRICE_WITHOUT_TAX',$product->prices);
					echo $this->currency->createPriceDiv('discountAmount','COM_VIRTUEMART_PRODUCT_DISCOUNT_AMOUNT',$product->prices);
					echo $this->currency->createPriceDiv('taxAmount','COM_VIRTUEMART_PRODUCT_TAX_AMOUNT',$product->prices);
					*/
					} ?>
				</div>
			</div>
			</a>
			<div class="clr"></div>
			<?php 
			// Add to cart btn panel?
			require_once JPATH_ROOT.'/templates/jtouch25/utils/jtouch25.utils.php';
			$tpl = Jtouch25Utils::getJtouchTemplate();
			//var_dump($tpl);die();
			$level1Btn = false;
			$pageTheme = 'd';
			if($tpl){
				$tplParams = new JRegistry($tpl->params);
				$level1Btn = ($tplParams->get('jtouch-virtuemart-btn-level1', 0) == 1);
				$pageTheme = $tplParams->get('jtouch-theme', 'd');
			}
			
			if($level1Btn): ?>
			<form method="post" class="product js-recalculate" action="index.php" id="addtocartproduct<?php echo $product->virtuemart_product_id; ?>">
				<div class="addtocart-bar">
					<?php // Add the button
					$button_lbl = JText::_('COM_VIRTUEMART_CART_ADD_TO');
					$button_cls = ''; //$button_cls = 'addtocart_button';
					if (VmConfig::get('check_stock') == '1' && !$product->product_in_stock) {
						$button_lbl = JText::_('COM_VIRTUEMART_CART_NOTIFY');
						$button_cls = 'notify-button';
					} ?>
					<div>
						<div class="width20 floatleft">
							<input type="number" data-mini="true" name="quantity[]" id="quantity-input-slider" class="quantity-input" value="<?php if(isset($product->min_order_level) && (int) $product->min_order_level > 0){echo $product->min_order_level;} else{ echo '1'; } ?>"/>
						</div>
						<div class="width80 floatright addtocart-button">
							<fieldset data-role="controlgroup" data-type="horizontal" data-mini="true" class="floatright tabs">
								<button name="quantity-plus" class="quantity-plus">&nbsp; + &nbsp;</button>
								<button name="cart_minus" class="quantity-minus">&nbsp; - &nbsp;</button>
								<input data-theme='<?php echo $pageTheme; ?>' type="submit" name="addtocart"  class="addtocart-button <?php echo $button_cls;?>" value="<?php echo $button_lbl ?>" title="<?php echo $button_lbl ?>" />
							</fieldset>
						</div>
						<div class="clr"></div>
					</div>
				</div>

				<?php // Display the add to cart button END ?>
				<input type="hidden" class="pname" value="<?php echo $product->product_name ?>">
				<input type="hidden" name="option" value="com_virtuemart" />
				<input type="hidden" name="view" value="cart" />
				<noscript><input type="hidden" name="task" value="add" /></noscript>
				<input type="hidden" name="virtuemart_product_id[]" value="<?php echo $product->virtuemart_product_id ?>" />
				<?php /** @todo Handle the manufacturer view */ ?>
				<input type="hidden" name="virtuemart_manufacturer_id" value="<?php echo $product->virtuemart_manufacturer_id ?>" />
				<input type="hidden" name="virtuemart_category_id[]" value="<?php echo $product->virtuemart_category_id ?>" />
			</form>	
			<?php 
			endif; // End add to cart btn panel 
			?>
		</div>
		
	</div>
<?php endforeach; // End the product list Output ?>
<div class="clr"></div>

<div class="pagination">
	<div class="counter"><?php echo $this->vmPagination->getPagesCounter(); ?></div>
	<?php echo $this->vmPagination->getPagesLinks(); ?>
	<div class="clr"></div>	
</div>


<?php
// Show child categories
if ( VmConfig::get('showCategory',1) ):
	if ($this->category->haschildren): ?>
		<div class="category-view">
			<h2><?php echo JText::_('COM_VIRTUEMART_SUBCATEGORIES');?></h2>
		<?php // Start the Output
		if(!empty($this->category->children)):
			foreach ( $this->category->children as $category ): 
				// Category Link
				$caturl = JRoute::_ ( 'index.php?option=com_virtuemart&view=category&virtuemart_category_id=' . $category->virtuemart_category_id );
			?>
			<div class="category floatleft">
				<div class="spacer">
					<a href="<?php echo $caturl ?>" title="<?php echo $category->category_name ?>">
						<?php if (!empty($category->images) ) {
							?>
							<span class="image"><?php echo $category->images[0]->displayMediaThumb("",false); ?></span>
							<?php
						} ?>
						<span class="category-name"><?php echo $category->category_name ?></span>
					</a>
				</div>
			</div>
			<?php
			endforeach;
		endif; ?>
			<div class="clr"></div>
		</div>
<?php 
	endif;  // End if has child categories
endif; // End show sub cat
?>
