<?php
/**
*
* Orderlist
* NOTE: This is a copy of the edit_orderlist template from the user-view (which in turn is a slighly
*       modified copy from the backend)
*
* @package	VirtueMart
* @subpackage Orders
* @author Oscar van Eijk
* @link http://www.virtuemart.net
* @copyright Copyright (c) 2004 - 2010 VirtueMart Team. All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
* VirtueMart is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* @version $Id: list.php 4630 2011-11-09 13:27:56Z alatak $
*/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');
if (count($this->orderlist) == 0) {
	//echo JText::_('COM_VIRTUEMART_ACC_NO_ORDER');
	 echo shopFunctionsF::getLoginForm(false,true);
} else { ?>
<ul data-role="listview" data-inset="true" data-mini="true">
	<?php 
	foreach ($this->orderlist as $row) :
		$editlink = JRoute::_('index.php?option=com_virtuemart&view=orders&layout=details&order_number=' . $row->order_number);
	?>
	<li>
		<a href="<?php echo $editlink; ?>">
			<div class="width40 floatleft vmname"><?php echo ShopFunctions::getOrderStatusName($row->order_status); ?></div>
			<div class="width60 floatright right"><?php echo $this->currency->priceDisplay($row->order_total); ?></div>
			<div class="clr"></div>
			<div class="description"><?php echo $row->order_number; ?></div>
			<div class="width50 floatleft description"><?php echo JHtml::_('date',$row->created_on, JText::_('DATE_FORMAT_LC4'));  ?></div>
			<div class="width50 floatright right description"><?php echo JHtml::_('date',$row->modified_on, JText::_('DATE_FORMAT_LC4'));  ?></div>
			<div class="clr"></div>
		</a>
	</li>
	<?php endforeach;?>
</ul>

<?php }?>
