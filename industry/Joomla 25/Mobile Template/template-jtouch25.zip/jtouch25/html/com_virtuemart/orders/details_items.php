<?php
/**
*
* Order items view
*
* @package	VirtueMart
* @subpackage Orders
* @author Oscar van Eijk
* @link http://www.virtuemart.net
* @copyright Copyright (c) 2004 - 2010 VirtueMart Team. All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
* VirtueMart is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* @version $Id: details_items.php 4599 2011-11-02 18:29:04Z alatak $
*/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');
?>
<h2><?php echo JText::_('COM_VIRTUEMART_ORDER_ITEM'); ?></h2>
<?php
	foreach($this->orderdetails['items'] as $item) :
		$_link = JRoute::_('index.php?option=com_virtuemart&view=productdetails&virtuemart_category_id=' . $item->virtuemart_category_id . '&virtuemart_product_id=' . $item->virtuemart_product_id);
?>
	<h4>
		[<?php echo $this->orderstatuses[$item->order_status]; ?>]
		<?php echo $item->order_item_sku; ?> : 
		<a href="<?php echo $_link; ?>"><?php echo $item->order_item_name; ?></a>
	</h4>
	<div>
		<?php
			if (!empty($item->product_attribute)) {
					if(!class_exists('VirtueMartModelCustomfields'))require(JPATH_VM_ADMINISTRATOR.DS.'models'.DS.'customfields.php');
					$product_attribute = VirtueMartModelCustomfields::CustomsFieldOrderDisplay($item);
				echo '<div>'.$product_attribute.'</div>';
			}
		?>
	</div>
	
	<div>
		<div class="width50 floatleft right"><?php echo JText::_('COM_VIRTUEMART_ORDER_PRINT_QTY') ?>:</div>
		<div class="width50 floatright right"><?php echo $item->product_quantity; ?></div>
		<div class="clr"></div>
	</div>

	<div>
		<div class="width50 floatleft right"><?php echo JText::_('COM_VIRTUEMART_ORDER_PRINT_PRICE') ?>:</div>
		<div class="width50 floatright right"><?php echo $this->currency->priceDisplay($item->product_final_price); ?></div>
		<div class="clr"></div>
	</div>

	<div>
		<div class="width50 floatleft right"><?php echo JText::_('COM_VIRTUEMART_ORDER_PRINT_TOTAL') ?>:</div>
		<div class="width50 floatright right"><b><?php echo $this->currency->priceDisplay($item->product_quantity * $item->product_final_price); ?></b></div>
		<div class="clr"></div>
	</div>
	<p> </p>
<?php endforeach; ?>
