<?php
/**
 *TODO Improve the CSS , ADD CATCHA ?
 * Show the form Ask a Question
 *
 * @package	VirtueMart
 * @subpackage
 * @author Kohl Patrick
 * @link http://www.virtuemart.net
 * @copyright Copyright (c) 2004 - 2010 VirtueMart Team. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 * VirtueMart is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
* @version $Id: default.php 2810 2011-03-02 19:08:24Z Milbo $
 */

// Check to ensure this file is included in Joomla!
defined ( '_JEXEC' ) or die ( 'Restricted access' );
$min = VmConfig::get('asks_minimum_comment_length', 50);
$max = VmConfig::get('asks_maximum_comment_length', 2000) ;
$formTitle = JText::_('COM_VIRTUEMART_PRODUCT_ASK_QUESTION');

$document = JFactory::getDocument();
//$document->addScript(JURI::root(true).'/components/com_virtuemart/assets/js/jquery.validation.js');
$document->addScriptDeclaration('
	$(document).bind("pageinit", function (toPage, properties){
		var askForm = $("#askform");
		askForm.validate({
		  rules: {
		    comment: {
		      required: true,
		      minlength: '.$min.',
		      maxlength: '.$max.'
		    }
		}});
		
		$("#vm_comment").keyup( function () {
			var result = $(this).val();
				$("#vm_counter").val( result.length );
		});
	}); 
', 'jtouch.jscode');

$exJsCode = <<< EOL
	function submitAskForm() {
		var askForm = $("#askform");
		if(!askForm.valid()) {
			return false;
		}
		//return true;
		var datas = askForm.serialize();
		$.post(siteurl+'index.php', datas,
			function(datas, textStatus) {
				var txt = '';
				if(textStatus == 'success'){
					txt = datas;
				}else{
					txt = 'Error while sending email';
				}
				$(document).simpledialog2({
					'mode' : 'button',
					'headerText' : '{$formTitle}',
					'buttonPrompt': txt,
				    'buttons' : {
				    	'OK': {
				         	click: function () {
				          		//Do nothing
				        	}
						}
				    }
				});
				
				//console.log(datas);
				//console.log(textStatus);
			}
		);
		
		return false;
	};
	
EOL;
$document->addScriptDeclaration($exJsCode, 'jtouch.jscode');

?>

<div class="ask-a-question-view">
	<h2><?php echo JText::_('COM_VIRTUEMART_PRODUCT_ASK_QUESTION')  ?></h2>
	
	<?php // Get User
	if (!empty($this->user->id)) {
		$user = JFactory::getUser();
	} ?>

	<div class="form-field">
		<form method="post" class="form-validate" action="<?php echo JRoute::_('index.php?option=com_virtuemart&view=productdetails&virtuemart_product_id='.$this->product->virtuemart_product_id.'&virtuemart_category_id='.$this->product->virtuemart_category_id.' ') ; ?>" name="askform" id="askform">
			<div data-role="fieldcontain">
				<label for="vm-user-name"><?php echo JText::_('COM_VIRTUEMART_USER_FORM_NAME')  ?></label>
				<input data-mini="true" type="text" value="<?php echo $this->user->name ?>" name="name" id="vm-user-name" class="required name"/>
			</div>
			
			<div data-role="fieldcontain">
				<label for="vm-user-email"><?php echo JText::_('COM_VIRTUEMART_USER_FORM_EMAIL')  ?></label>
				<input data-mini="true" type="text" value="<?php echo $this->user->email ?>" name="email" id="vm-user-email" class="required email"/>
			</div>
			
			<div data-role="fieldcontain">
				<label for="vm_comment">
					<?php
					$ask_comment = JText::sprintf('COM_VIRTUEMART_ASK_COMMENT', $min, $max);
					echo $ask_comment;
					?>
				</label>
				<textarea data-mini="true" title="<?php echo $ask_comment ?>" id="vm_comment" name="comment" rows="10" class="required range"></textarea>
			</div>
			
			<div>
				<div class="floatleft width50">
					<label for="vm-counter"><?php echo JText::_('COM_VIRTUEMART_ASK_COUNT')  ?></label>
				</div>
				<div class="floatright width50">
					<input data-mini="true" type="text" value="0" class="counter" id="vm_counter" name="counter" maxlength="4" readonly="readonly" />
				</div>
				<div class="clr"></div>
			</div>
			
			<div class="submit">
				<input data-mini="true" data-inline="true" onClick="return submitAskForm();" class="highlight-button" type="submit"  name="submit_ask" title="<?php echo JText::_('COM_VIRTUEMART_ASK_SUBMIT')  ?>" value="<?php echo JText::_('COM_VIRTUEMART_ASK_SUBMIT')  ?>" />
			</div>

			<input type="hidden" name="cid[]" value="<?php echo $this->product->virtuemart_product_id; ?>" />
			<input type="hidden" name="virtuemart_product_id" value="<?php echo $this->product->virtuemart_product_id; ?>" />
			<input type="hidden" name="view" value="productdetails" />
			<input type="hidden" name="option" value="com_virtuemart" />
			<input type="hidden" name="tmpl" value="component" />
			<input type="hidden" name="virtuemart_category_id" value="<?php echo $this->product->virtuemart_category_id; ?>" />
			<?php echo JHTML::_( 'form.token' ); ?>
			<input type="hidden" name="task" value="mailAskquestion" />
		</form>
	</div>
</div>