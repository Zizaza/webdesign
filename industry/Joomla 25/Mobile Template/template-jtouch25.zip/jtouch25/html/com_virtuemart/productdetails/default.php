<?php
/**
 *
 * Show the product details page
 *
 * @package	VirtueMart
 * @subpackage
 * @author Max Milbers, Eugen Stranz
 * @author RolandD,
 * @author Nguyen @ MobileMeWs.com
 * @todo handle child products
 * @link http://www.virtuemart.net
 * @copyright Copyright (c) 2004 - 2010 VirtueMart Team. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 * VirtueMart is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * @version $Id: default.php 4853 2011-11-28 22:35:57Z Milbo $
 */

// Check to ensure this file is included in Joomla!
defined ( '_JEXEC' ) or die ( 'Restricted access' );


/* Let's see if we found the product */
if (empty ( $this->product )) {
	echo JText::_ ( 'COM_VIRTUEMART_PRODUCT_NOT_FOUND' );
	echo '<br /><br />  ' . $this->continue_link_html;
	return;
}
$document = JFactory::getDocument();
// Photoswipe slideshow http://www.photoswipe.com/
$document->addStyleSheet($this->baseurl.'/templates/jtouch25/client-libs/photoswipe/photoswipe.min.css', 'jtouch.cssfile');
$document->addScript($this->baseurl.'/templates/jtouch25/client-libs/photoswipe/klass.min.js', 'jtouch.jsfile');
$document->addScript($this->baseurl.'/templates/jtouch25/client-libs/photoswipe/code.photoswipe.jquery-3.0.4.min.js', 'jtouch.jsfile');

$script = <<<EOL

$(document).bind('pageshow', function (){
	// Setup product tabs
	if(!this.productDetailTabs){
		console.log('Init tab bar for product details page');
		this.productDetailTabs = new Jtouch.Ui.ButtonTabs('#vm-product-details');
	}
	
	// Gallery
	if(!this.myPhotoSwipe){
		console.log('Init gallery for product details page');
		this.myPhotoSwipe = true;
		
		$('#showGalleryPage').on('click', function(e){
			e.preventDefault();
			$("body").animate({ scrollTop: 0 }, 
				{
					complete: function(){
						console.log('show gallery');
						$("#Gallery a").photoSwipe().show(0);
					}
				}
			);
		});	
	}
});

EOL;

$document->addScriptDeclaration($script, 'jtouch.jscode');

$askQuestionUrl = JRoute::_('index.php?option=com_virtuemart&view=productdetails&task=askquestion&virtuemart_product_id='.$this->product->virtuemart_product_id.'&virtuemart_category_id='.$this->product->virtuemart_category_id.'&tmpl=component');

?>

<div id="vm-product-details">
	<h2><?php echo $this->product->product_name ?></h2>
	<!-- TAB CONTROLS -->
	<div class="center tabs">
		<fieldset data-role="controlgroup" data-type="horizontal" data-mini="true" style="display:inline;">
         	<input type="radio" name="vm-product-details-tabs" id="vm-product-details-tab1" class="jtouch-button-tab" value="#vm-product-details-main" checked="checked" />
         	<label for="vm-product-details-tab1"><?php echo JText::_('Main');?></label>
         	
         	<input type="radio" name="vm-product-details-tabs"  id="vm-product-details-tab2" class="jtouch-button-tab" value="#vm-product-details-details" />
         	<label for="vm-product-details-tab2"><?php echo JText::_('Details');?></label>
         	
			<?php if($this->allowRating || $this->showReview): ?>
         	<input type="radio" name="vm-product-details-tabs"  id="vm-product-details-tab3" class="jtouch-button-tab" value="#vm-product-details-reivew" />
         	<label for="vm-product-details-tab3"><?php echo JText::_('Review');?></label>
         	<?php endif;?>
         	
         	<input type="radio" name="vm-product-details-tabs"  id="vm-product-details-tab4" class="jtouch-button-tab" value="#vm-product-details-ask" />
         	<label for="vm-product-details-tab4"><?php echo JText::_('Ask');?></label>
   	 	</fieldset>
    </div>
			
	<!-- TAB MAIN: -->
	<div id="vm-product-details-main" class="jtouch-tab">
		<?php // Product Main Image
		if (!empty($this->product->images[0])):
			$galleryId = ''; 
			if(!empty($this->product->images) && count($this->product->images)>1){
				$galleryId = ' id="showGalleryPage"';
			}
			
		?>
		
		<div class="main-image">
			<a href="#" <?php echo $galleryId;?>>
				<?php echo $this->product->images[0]->displayMediaThumb("",false); ?>
			</a>
		</div>
		<?php endif; // Product Main Image END ?>
		
		<?php // Showing The Additional Images
		if($galleryId != ''): ?>
			<div class="center description"><?php echo JText::_('JTOUCH25_VM_GALLERY_VIEW_MORE');?></div>
			<div id="gallery-prd<?php echo $this->product->virtuemart_product_id;?>" style="display:none;">
				<ul id="Gallery" class="gallery">
					<?php // List all Images
					$sitePath = JURI::base();
					foreach ($this->product->images as $image): ?>
						<li><a href="<?php echo $sitePath.$image->file_url; ?>"><img alt="<?php echo $this->product->product_name ?>" /></a></li>
					<?php endforeach; // end slideshow ?>
				</ul><!-- #photoswipe -->
				<div class="clr"></div>
			</div>
		<?php endif; // Showing The Additional Images END ?>
		
		<?php // Add To Cart Button
		if (!VmConfig::get('use_as_catalog',0)) { ?>
		<div class="addtocart-area">

			<form method="post" class="product js-recalculate" action="index.php" id="addtocartproduct<?php echo $this->product->virtuemart_product_id ?>">
			<?php // Product custom_fields
			if (!empty($this->product->customfieldsCart)) {  ?>
			<div class="product-fields">
				<?php foreach ($this->product->customfieldsCart as $field){ ?>
				<div class="product-field product-field-type-<?php echo $field->field_type ?>">
					<h3><?php echo  JText::_($field->custom_title) ?></h3>
					<div class="product-field-desc"><?php echo $field->custom_field_desc ?></div>
					<div class="product-field-display"><?php echo $field->display ?></div>
				</div>
				<?php } ?>
			</div>
			<?php }
			 /* Product custom Childs
			  * to display a simple link use $field->virtuemart_product_id as link to child product_id
			  * custom_value is relation value to child
			  */

			if (!empty($this->product->customsChilds)) {  ?>
				<div class="product-fields">
					<?php foreach ($this->product->customsChilds as $field) {  ?>
					<div class="product-field product-field-type-<?php echo $field->field->field_type ?>">
						<h3><?php echo JText::_($field->field->custom_title) ?></h3>
						<div class="product-field-desc"><?php echo JText::_($field->field->custom_value) ?></div>
						<div class="product-field-display"><?php echo $field->display ?></div>

					</div>
					<?php } ?>
				</div>
			<?php } ?>

			<div class="addtocart-bar">
				<?php // Add the button
				$button_lbl = JText::_('COM_VIRTUEMART_CART_ADD_TO');
				$button_cls = ''; //$button_cls = 'addtocart_button';
				if (VmConfig::get('check_stock') == '1' && !$this->product->product_in_stock) {
					$button_lbl = JText::_('COM_VIRTUEMART_CART_NOTIFY');
					$button_cls = 'notify-button';
				} ?>
				<div>
					<div class="width20 floatleft">
						<input type="number" data-mini="true" name="quantity[]" id="quantity-input-slider" class="quantity-input" value="<?php if(isset($this->product->min_order_level) && (int) $this->product->min_order_level > 0){echo $this->product->min_order_level;} else{ echo '1'; } ?>"/>
					</div>
					<div class="width80 floatright addtocart-button">
						<fieldset data-role="controlgroup" data-type="horizontal" data-mini="true" class="floatright tabs">
							<button name="quantity-plus" class="quantity-plus">&nbsp; + &nbsp;</button>
							<button name="cart_minus" class="quantity-minus">&nbsp; - &nbsp;</button>
							<input data-theme='b' type="submit" name="addtocart"  class="addtocart-button <?php echo $button_cls;?>" value="<?php echo $button_lbl ?>" title="<?php echo $button_lbl ?>" />
						</fieldset>
					</div>
					<div class="clr"></div>
				</div>
			</div>

				<?php // Display the add to cart button END ?>
				<input type="hidden" class="pname" value="<?php echo $this->product->product_name ?>">
				<input type="hidden" name="option" value="com_virtuemart" />
				<input type="hidden" name="view" value="cart" />
				<noscript><input type="hidden" name="task" value="add" /></noscript>
				<input type="hidden" name="virtuemart_product_id[]" value="<?php echo $this->product->virtuemart_product_id ?>" />
				<?php /** @todo Handle the manufacturer view */ ?>
				<input type="hidden" name="virtuemart_manufacturer_id" value="<?php echo $this->product->virtuemart_manufacturer_id ?>" />
				<input type="hidden" name="virtuemart_category_id[]" value="<?php echo $this->product->virtuemart_category_id ?>" />
			</form>
			<div class="clr"></div>
		</div>
		<?php }  // Add To Cart Button END ?>
		
		<?php // Product Short Description
		if (!empty($this->product->product_s_desc)) : ?>
		
		<div class="product-short-description">
			<?php /** @todo Test if content plugins modify the product description */
			echo $this->product->product_s_desc; ?>
		</div>
		<?php endif; // Product Short Description END ?>
		
		<?php // Product Price
		if ($this->show_prices) { ?>
		<div class="product-price" id="productPrice<?php echo $this->product->virtuemart_product_id ?>">
		<?php
		if ($this->product->product_unit && VmConfig::get ( 'price_show_packaging_pricelabel' )) {
			echo "<strong>" . JText::_ ( 'COM_VIRTUEMART_CART_PRICE_PER_UNIT' ) . ' (' . $this->product->product_unit . "):</strong>";
		} else {
			echo "<strong>" . JText::_ ( 'COM_VIRTUEMART_CART_PRICE' ) . "</strong>";
		}

		if ($this->showBasePrice) {
			echo $this->currency->createPriceDiv ( 'basePrice', 'COM_VIRTUEMART_PRODUCT_BASEPRICE', $this->product->prices );
			echo $this->currency->createPriceDiv ( 'basePriceVariant', 'COM_VIRTUEMART_PRODUCT_BASEPRICE_VARIANT', $this->product->prices );
		}

		echo $this->currency->createPriceDiv ( 'variantModification', 'COM_VIRTUEMART_PRODUCT_VARIANT_MOD', $this->product->prices );
		echo $this->currency->createPriceDiv ( 'basePriceWithTax', 'COM_VIRTUEMART_PRODUCT_BASEPRICE_WITHTAX', $this->product->prices );
		echo $this->currency->createPriceDiv ( 'discountedPriceWithoutTax', 'COM_VIRTUEMART_PRODUCT_DISCOUNTED_PRICE', $this->product->prices );
		echo $this->currency->createPriceDiv ( 'salesPriceWithDiscount', 'COM_VIRTUEMART_PRODUCT_SALESPRICE_WITH_DISCOUNT', $this->product->prices );
		echo $this->currency->createPriceDiv ( 'salesPrice', 'COM_VIRTUEMART_PRODUCT_SALESPRICE', $this->product->prices );
		echo $this->currency->createPriceDiv ( 'priceWithoutTax', 'COM_VIRTUEMART_PRODUCT_SALESPRICE_WITHOUT_TAX', $this->product->prices );
		echo $this->currency->createPriceDiv ( 'discountAmount', 'COM_VIRTUEMART_PRODUCT_DISCOUNT_AMOUNT', $this->product->prices );
		echo $this->currency->createPriceDiv ( 'taxAmount', 'COM_VIRTUEMART_PRODUCT_TAX_AMOUNT', $this->product->prices ); ?>
		</div>
		<?php } // Product Price?>
		
		<?php // Availability Image
		/* TO DO add width and height to the image */
		if (!empty($this->product->product_availability)) { ?>
			<div class="availability">
				<?php echo JHTML::image(JURI::root().VmConfig::get('assets_general_path').'images/availability/'.$this->product->product_availability, $this->product->product_availability, array('class' => 'availability')); ?>
			</div>
		<?php } // Availability Image:end ?>
		
	</div>
	<!-- TAB MAIN: END -->
	
	<!-- TAB DETAILS -->
	<div id="vm-product-details-details" class="jtouch-tab">
		<?php // Manufacturer of the Product
		if(VmConfig::get('show_manufacturer', 1) && !empty($this->product->virtuemart_manufacturer_id)) { ?>
		<div class="manufacturer">
		<?php
			$link = JRoute::_('index.php?option=com_virtuemart&view=manufacturer&virtuemart_manufacturer_id='.$this->product->virtuemart_manufacturer_id);
			$text = $this->product->mf_name;

			/* Avoid JavaScript on PDF Output */
			if (strtolower(JRequest::getWord('output')) == "pdf"){
				echo JHTML::_('link', $link, $text);
			} else { ?>
				<span class="bold"><?php echo JText::_('COM_VIRTUEMART_PRODUCT_DETAILS_MANUFACTURER_LBL') ?></span><a class="modal" rel="{handler: 'iframe', size: {x: 700, y: 550}}" href="<?php echo $link ?>"><?php echo $text ?></a>
		<?PHP } ?>
		</div>
		<?php } // Manufacturer of the Product:end ?>
		
		<?php // Product Description
		if (!empty($this->product->product_desc)) { ?>
		<div class="product-description">
			<?php /** @todo Test if content plugins modify the product description */ ?>
			<span class="title"><?php echo JText::_('COM_VIRTUEMART_PRODUCT_DESC_TITLE') ?></span>
			<?php echo $this->product->product_desc; ?>
		</div>
		<?php } // Product Description END ?>
	
	</div>
	<!-- TAB DETAILS:END -->
	
	<!-- TAB REVIEW -->
	<?php echo $this->loadTemplate('review');?>
	<!-- TAB REVIEW:END -->
	
	<!-- TAB ASK A QUESTION  -->
	<div id="vm-product-details-ask" class="jtouch-tab">
		<?php echo $this->loadTemplate('askform');?>
	</div>
	<!-- TAB ASK A QUESTION:END  -->
</div>
