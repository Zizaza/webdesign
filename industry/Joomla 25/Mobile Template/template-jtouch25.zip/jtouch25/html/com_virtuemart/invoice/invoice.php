<?php
/**
*
* Order detail view
*
* @package	VirtueMart
* @subpackage Orders
* @author Oscar van Eijk, Valerie Isaksen
* @link http://www.virtuemart.net
* @copyright Copyright (c) 2004 - 2010 VirtueMart Team. All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
* VirtueMart is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* @version $Id: details.php 5412 2012-02-09 19:27:55Z alatak $
*/
//index.php?option=com_virtuemart&view=invoice&layout=invoice&format=pdf&tmpl=component&order_number=xx&order_pass=p_yy
//
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');
//JHTML::stylesheet('vmpanels.css', JURI::root().'components/com_virtuemart/assets/css/');
if ($this->_layout=="invoice") {
$document = JFactory::getDocument();
$document->setTitle(JText::_('COM_VIRTUEMART_ORDER_PRINT_PO_NUMBER').' '.$this->orderDetails['details']['BT']->order_number.' '.$this->vendor->vendor_store_name);
//$document->setName( JText::_('COM_VIRTUEMART_ACC_ORDER_INFO').' '.$this->orderDetails['details']['BT']->order_number);
//$document->setDescription( JText::_('COM_VIRTUEMART_ORDER_PRINT_PO_NUMBER').' '.$this->orderDetails['details']['BT']->order_number);
}

if($this->headFooter){ ?>
<div class="vendor-details-view">
	<h1><?php echo $this->vendor->vendor_store_name;
	if (!empty($this->vendor->images[0])) { ?>
		<div class="vendor-image">
		<?php echo $this->vendor->images[0]->displayMediaThumb('',false); ?>
		</div>
	<?php
	}
	?>	
	</h1>
</div>

<div class="vendor-description"> 
	<?php echo $this->vendorAddress; ?>
</div>	
<?php } ?>

 
<?php if($this->print){ ?>
	<body onload="javascript:print();">
		<div class='spaceStyle'>
		<?php echo $this->loadTemplate('order'); ?>
		</div>

		<div class='spaceStyle'>
		<?php echo $this->loadTemplate('items'); ?>
		</div>
	</body>
	<?php
} else {
	echo $this->loadTemplate('order');
?>

	<div class='spaceStyle'>
	<?php
	$tabarray = array();

	$tabarray['items'] = 'COM_VIRTUEMART_ORDER_ITEM';
	$tabarray['history'] = 'COM_VIRTUEMART_ORDER_HISTORY';

	shopFunctionsF::buildTabs ($tabarray);
	?>
	</div>
	
	<br clear="all"/><br/>
<?php }

if($this->headFooter){
	echo $this->vendor->vendor_legal_info;
}

?>






