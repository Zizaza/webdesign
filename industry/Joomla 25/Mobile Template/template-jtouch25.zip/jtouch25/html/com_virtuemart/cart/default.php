<?php
/**
*
* Layout for the shopping cart
*
* @package	VirtueMart
* @subpackage Cart
* @author Max Milbers
*
* @link http://www.virtuemart.net
* @copyright Copyright (c) 2004 - 2010 VirtueMart Team. All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
* VirtueMart is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* @version $Id: cart.php 2551 2010-09-30 18:52:40Z milbo $
*/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');
//JHtml::_('behavior.formvalidation');
//JHTML::_ ( 'behavior.modal' );
// vmdebug('cart',$this->cart);
?>

<div class="cart-view">
	<h1><?php echo JText::_('COM_VIRTUEMART_CART_TITLE'); ?></h1>
	<?php if (VmConfig::get('oncheckout_show_steps', 1) && $this->checkout_task==='confirm'){
		vmdebug('checkout_task',$this->checkout_task);
		echo '<div class="checkoutStep" id="checkoutStep4">'.JText::_('COM_VIRTUEMART_USER_FORM_CART_STEP4').'</div>';
	} ?>
	<?php // Continue Shopping Button
	if ($this->continue_link_html != '') {
		echo $this->continue_link_html;
	} ?>
	<div class="clr"></div>
</div>


<?php 
	echo shopFunctionsF::getLoginForm($this->cart,false);
	// This displays the pricelist MUST be done with tables, because it is also used for the emails
	
	echo $this->loadTemplate('pricelist');
	if ($this->checkout_task) $taskRoute = '&task='.$this->checkout_task;
	else $taskRoute ='';
	
	// Check if require login or not
	$formStyle = "";
	if ((int)VmConfig::get('oncheckout_only_registered') == 1){
		$user	= JFactory::getUser();
		if ($user->get('guest')) {
			$formStyle = "display:none;";
		}
	}
	?>
<div style="<?php echo $formStyle; ?>">	
	<form method="post" id="checkoutForm" name="checkoutForm" action="<?php echo JRoute::_( 'index.php?option=com_virtuemart&view=cart'.$taskRoute,$this->useXHTML,$this->useSSL ); ?>">

		<?php // Leave A Comment Field ?>
		<div class="customer-comment marginbottom15">
			<h3><?php echo JText::_('COM_VIRTUEMART_COMMENT'); ?></h3>
			<textarea class="customer-comment" name="customer_comment" cols="50" rows="4"><?php echo $this->cart->customer_comment; ?></textarea>
		</div>
		<?php // Leave A Comment Field END ?>

		<?php // Terms Of Service
		if(VmConfig::get('oncheckout_show_legal_info',1)){
		?>
		<div class="terms-of-service">
			<h3><span class="vmicon vm2-termsofservice-icon"></span><?php echo JText::_('COM_VIRTUEMART_CART_TOS'); ?></h3>
			<div>
			<?php
			echo $this->cart->vendor->vendor_terms_of_service;?>
			</div>
		</div>
		<?php
		} // Terms Of Service END ?>

		<?php // Continue and Checkout Button ?>
		<div class="checkout-button-top">

			<?php // Terms Of Service Checkbox
			if (!class_exists('VirtueMartModelUserfields')){
				require(JPATH_VM_ADMINISTRATOR . DS . 'models' . DS . 'userfields.php');
			}
			$userFieldsModel = new VirtueMartModelUserfields();
			if($userFieldsModel->getIfRequired('agreed')){ ?>
			<div data-role="fieldcontain" data-mini="true">
			    <fieldset data-role="controlgroup">
				   <legend><?php echo JText::_('COM_VIRTUEMART_CART_TOS_READ_AND_ACCEPTED'); ?></legend>
				   <input type="hidden" name="tosAccepted" value="0">
				   <input data-mini="true" class="terms-of-service custom" id="tosAccepted" type="checkbox" name="tosAccepted" value="1" checked="checked" />
				   <label for="tosAccepted">I agree</label>
			    </fieldset>
			</div>
			<p>&nbsp;</p>
			<?php
			}

			echo $this->checkout_link_html;
			$text = JText::_('COM_VIRTUEMART_ORDER_CONFIRM_MNU');
			?>
		</div>
		<?php //vmdebug('my cart',$this->cart);// Continue and Checkout Button END ?>

		<input type='hidden' name='task' value='<?php echo $this->checkout_task; ?>'/>
		<input type='hidden' name='option' value='com_virtuemart'/>
		<input type='hidden' name='view' value='cart'/>
	</form>
	<p>&nbsp;</p>
	<div class="clr"></div>
</div>