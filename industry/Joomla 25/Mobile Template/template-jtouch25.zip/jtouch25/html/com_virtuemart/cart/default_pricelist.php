<?php defined('_JEXEC') or die('Restricted access');
/**
 *
 * Layout for the shopping cart
 *
 * @package	VirtueMart
 * @subpackage Cart
 * @author Max Milbers
 * @author Patrick Kohl
 * @link http://www.virtuemart.net
 * @copyright Copyright (c) 2004 - 2010 VirtueMart Team. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 * VirtueMart is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 *
 */

// Check to ensure this file is included in Joomla!

// jimport( 'joomla.application.component.view');
// $viewEscape = new JView();
// $viewEscape->setEscape('htmlspecialchars');
$document = JFactory::getDocument();
$script = <<<EOL
	function jtouchToggleProductEdit(el) {
		console.log(el);
		$('#' + el).fadeToggle();
	}
	
EOL;
$document->addScriptDeclaration($script, 'jtouch.jscode');
?>
<div id="vm-bill-to">
	<h3><?php echo JText::_('COM_VIRTUEMART_USER_FORM_BILLTO_LBL'); ?></h3>
	<div>
		<?php

		foreach($this->cart->BTaddress['fields'] as $item){
			if(!empty($item['value'])){
				if($item['name']==='agreed'){
					$item['value'] =  ($item['value']===0) ? JText::_('COM_VIRTUEMART_USER_FORM_BILLTO_TOS_NO'):JText::_('COM_VIRTUEMART_USER_FORM_BILLTO_TOS_YES');
				}
				?><!-- span class="titles"><?php echo $item['title'] ?></span -->
					<span class="values vm2<?php echo '-'.$item['name'] ?>" ><?php echo $this->escape($item['value']) ?></span>
				<?php if ($item['name'] != 'title' and $item['name'] != 'first_name' and $item['name'] != 'middle_name' and $item['name'] != 'zip') { ?>
					<br class="clear" />
				<?php
				}
			}
		} ?>
		<div class="clr"></div>
		<a data-role="button" data-inline="true" data-mini="true" class="details" href="<?php echo JRoute::_('index.php?option=com_virtuemart&view=user&task=editaddresscart&addrtype=BT',$this->useXHTML,$this->useSSL) ?>">
			<?php echo JText::_('COM_VIRTUEMART_USER_FORM_EDIT_BILLTO_LBL'); ?>
		</a>
		
	</div>
</div>

<div id="vm-ship-to">
	<h3><?php echo JText::_('COM_VIRTUEMART_USER_FORM_SHIPTO_LBL'); ?></h3>
	<div>
		<?php
		if(empty($this->cart->STaddress['fields'])){
			echo JText::sprintf('COM_VIRTUEMART_USER_FORM_EDIT_BILLTO_EXPLAIN',JText::_('COM_VIRTUEMART_USER_FORM_ADD_SHIPTO_LBL') );
		} else {
			if(!class_exists('VmHtml'))require(JPATH_VM_ADMINISTRATOR.DS.'helpers'.DS.'html.php');
			echo JText::_('COM_VIRTUEMART_USER_FORM_ST_SAME_AS_BT'). VmHtml::checkbox('STsameAsBT',$this->cart->STsameAsBT).'<br />';
			foreach($this->cart->STaddress['fields'] as $item){
				if(!empty($item['value'])){ ?>
					<!-- <span class="titles"><?php echo $item['title'] ?></span> -->
					<?php
					if ($item['name'] == 'first_name' || $item['name'] == 'middle_name' || $item['name'] == 'zip') { ?>
						<span class="values<?php echo '-'.$item['name'] ?>" ><?php echo $this->escape($item['value']) ?></span>
					<?php } else { ?>
						<span class="values" ><?php echo $this->escape($item['value']) ?></span>
						<br class="clear" />
					<?php
					}
				}
			}
		}
 		?>
		<div class="clr"></div>

		<?php if(!isset($this->cart->lists['current_id'])) $this->cart->lists['current_id'] = 0; ?>
		<a data-role="button" data-inline="true" data-mini="true" class="details" href="<?php echo JRoute::_('index.php?option=com_virtuemart&view=user&task=editaddresscart&addrtype=ST&cid[]='.$this->cart->lists['current_id'],$this->useXHTML,$this->useSSL) ?>">
			<?php echo JText::_('COM_VIRTUEMART_USER_FORM_ADD_SHIPTO_LBL'); ?>
		</a>
	</div>
</div>

<fieldset>
	<table
		class="cart-summary"
		cellspacing="0"
		cellpadding="2"
		border="0"
		width="100%">
		<thead>
			<tr>
				<th align="left" style="width: 70%;"><h3><?php echo JText::_('COM_VIRTUEMART_ORDER_ITEM'); ?></h3> </th>
				<th align="right" style="width: 30%;">&nbsp;</th>
			</tr>
		</thead>

		<?php
		$i=1;
		foreach( $this->cart->products as $pkey =>$prow ) { ?>
			<tr valign="top" class="sectiontableentry<?php echo $i ?>">
				<td>
					
					<?php if ( $prow->virtuemart_media_id) {  ?>
						<div class="cart-images">
						 <?php
						 if(!empty($prow->image)) echo $prow->image->displayMediaThumb('',false);
						 ?>
						</div>
					<?php } ?>
					
					<?php echo $prow->product_sku ?> - 
					<?php echo JHTML::link($prow->url, $prow->product_name).$prow->customfields; ?>

				</td>
				<td align="right">
					<button data-inline="true" data-icon="gear" data-iconpos="notext" onClick="jtouchToggleProductEdit('edit-product-<?php echo $i ;?>')">Edit</button>
				</td>
			</tr>
			
			<!-- R2 + PRICE -->
			<tr>
				<td colspan="2">
					<div id="edit-product-<?php echo $i ;?>" class="edit-product-tool">
						<form action="index.php" method="post" class="product" style="display: inline;">
							<div class="addtocart-area">
								<div class="width20 floatleft">
									<input type="number" data-mini="true"  name="quantity" id="quantity-input-slider" class="quantity-input" min="1" max="100"  value="<?php echo $prow->quantity ?>"/>
								</div>
								<div class="width80 floatright">
									<fieldset data-role="controlgroup" data-mini="true" data-type="horizontal" class="floatright tabs" style="margin: 0 auto !important;">
										<button name="quantity-plus" class="quantity-plus">+</button>
										<button name="cart_minus" class="quantity-minus"> - </button>
									</fieldset>
								</div>
								<div class="clr"></div>
							</div>
							
							<!--   <input type="range" id="quantity-slider" class="quantity-input" min="1" max="100"  title="<?php echo  JText::_('COM_VIRTUEMART_CART_UPDATE') ?>" class="inputbox" size="3" maxlength="4" name="quantity" value="<?php echo $prow->quantity ?>" /> -->
							
							<div data-role="fieldcontain">
								<fieldset class="ui-grid-a">
						  			<div class="ui-block-a"><button data-icon="check" data-mini="true" type="submit" name="update" title="<?php echo  JText::_('COM_VIRTUEMART_CART_UPDATE') ?>" value="Update"/></div>
									<div class="ui-block-b"><a data-role="button" data-icon="delete" data-mini="true" title="<?php echo JText::_('COM_VIRTUEMART_CART_DELETE') ?>" href="<?php echo JRoute::_('index.php?option=com_virtuemart&view=cart&task=delete&cart_virtuemart_product_id='.$prow->cart_item_id  ) ?>">Delete</a></div>
								</fieldset>
							</div>
							<input type="hidden" name="option" value="com_virtuemart" />
							<input type="hidden" name="view" value="cart" />
							<input type="hidden" name="task" value="update" />
							<input type="hidden" name="cart_virtuemart_product_id" value="<?php echo $prow->cart_item_id  ?>" />
						</form>
					</div>
				</td>
			</tr>
			<tr>
				<td align="right"><?php echo JText::_('COM_VIRTUEMART_CART_QUANTITY') ?>:</td>
				<td align="right"><hr class="vmhr" /><?php echo $prow->quantity ?></td>
			</tr>
			<tr>
				<td align="right"><?php echo JText::_('COM_VIRTUEMART_CART_PRICE') ?></td>
				<td align="right" >
					<?php
						echo $this->currencyDisplay->createPriceDiv('priceWithoutTax','', $this->cart->pricesUnformatted[$pkey],false);
					?>
				</td>
			</tr>	
			
			<!-- R3 -->
			<?php if ( VmConfig::get('show_tax')) { ?>
			<tr>
				<td align="right"><?php echo JText::_('COM_VIRTUEMART_CART_SUBTOTAL_TAX_AMOUNT') ?>: </td>
				<td align="right"><?php echo "<span  class='priceColor2'>".$this->currencyDisplay->createPriceDiv('taxAmount','', $this->cart->pricesUnformatted[$pkey],false)."</span>" ?></td>
			</tr>
			<?php } ?>
			
			<!-- R4 -->
			<tr>
				<td align="right"><?php echo JText::_('COM_VIRTUEMART_CART_SUBTOTAL_DISCOUNT_AMOUNT') ?>:</td>
				<td align="right"><?php echo "<span class='priceColor2'>".$this->currencyDisplay->createPriceDiv('discountAmount','', $this->cart->pricesUnformatted[$pkey],false)."</span>" ?></td>
			</tr>
			
			<!-- R5 -->
			<tr>
				<td align="right"><?php echo JText::_('COM_VIRTUEMART_CART_TOTAL') ?>:</td>
				<td align="right">
					<hr class="vmhr" />
					<?php 
						if (VmConfig::get('checkout_show_origprice',1) && !empty($this->cart->pricesUnformatted[$pkey]['basePriceWithTax']) && $this->cart->pricesUnformatted[$pkey]['basePriceWithTax'] != $this->cart->pricesUnformatted[$pkey]['salesPrice'] ) {
							echo '<span class="line-through priceColor2">'.$this->currencyDisplay->createPriceDiv('basePriceWithTax','', $this->cart->pricesUnformatted[$pkey],true,false,$prow->quantity) .'</span><br />' ;
						}
						
						echo $this->currencyDisplay->createPriceDiv('salesPrice','', $this->cart->pricesUnformatted[$pkey],false,false,$prow->quantity);
					?>
				</td>
			</tr>
			<tr><td colspan="2"><hr class="vmhr" /></td></tr>
		<?php
			$i++;
		} //End product items loop ?>
		
		<!--Begin of SubTotal, Tax, Shipment, Coupon Discount and Total listing -->

	  	<tr>
			<td colspan="2">&nbsp;</td>
	  	</tr>
		  
	  	<tr class="sectiontableentry2">
			<td><h3><?php echo JText::_('COM_VIRTUEMART_ORDER_PRINT_PRODUCT_PRICES_TOTAL') ?></h3></td>
			<td>&nbsp;</td>
		</tr>
		
		<?php if ( VmConfig::get('show_tax')) { ?>
		<tr class="sectiontableentry2">
			<td align="right">Tax:</td>
			<td align="right"> <?php echo "<span  class='priceColor2' >".$this->currencyDisplay->createPriceDiv('taxAmount','', $this->cart->pricesUnformatted,false)."</span>" ?> </td>
		</tr>
		<?php }?>
		
		<tr class="sectiontableentry2">
			<td align="right">Discount Amount:</td>
			<td align="right"> <?php echo "<span  class='priceColor2' >".$this->currencyDisplay->createPriceDiv('discountAmount','', $this->cart->pricesUnformatted,false)."</span>" ?> </td>
		</tr>

		<tr class="sectiontableentry2">
			<td align="right">Total:</td>
			<td align="right"> <?php echo "<span  class='priceColor2' >".$this->currencyDisplay->createPriceDiv('salesPrice','', $this->cart->pricesUnformatted,false)."</span>" ?> </td>
		</tr>
		
		<?php if (VmConfig::get('coupons_enable')): ?>
		<tr class="sectiontableentry2">
			<td align="right" colspan="2">
				<?php 
					if(!empty($this->layoutName) && $this->layoutName=='default') {
				    	echo $this->loadTemplate('coupon');
			    	}
			    	
			    	if (!empty($this->cart->cartData['couponCode'])) {
						echo $this->cart->cartData['couponCode'] ;
						echo $this->cart->cartData['couponDescr'] ? (' (' . $this->cart->cartData['couponDescr'] . ')' ): '';
			    	}
				?>
			</td>
		</tr>
		<?php if ( VmConfig::get('show_tax')): ?>
		<tr class="sectiontableentry2">
			<td align="right">Coupon Tax:</td>
			<td align="right"> <?php echo "<span  class='priceColor2' >".$this->currencyDisplay->createPriceDiv('salesPrice','', $this->cart->pricesUnformatted,false)."</span>" ?> </td>
		</tr>
		<?php endif;?>
		<tr class="sectiontableentry2">
			<td align="right">Coupon Amount:</td>
			<td align="right"> <?php echo "<span  class='priceColor2' >".$this->currencyDisplay->createPriceDiv('salesPriceCoupon','', $this->cart->pricesUnformatted['salesPriceCoupon'],false)."</span>" ?> </td>
		</tr>
		<?php endif; //End coupon ?>
		
		<?php
		foreach($this->cart->cartData['DBTaxRulesBill'] as $rule): ?>
		<tr class="sectiontableentry<?php $i ?>">
			<td align="right" colspan="2">
				<?php echo $rule['calc_name'] ?> 
			</td>
		</tr>
		<?php if ( VmConfig::get('show_tax')): ?>
		<tr class="sectiontableentry2">
			<td align="right">Tax:</td>
			<td align="right"> <?php echo $this->currencyDisplay->createPriceDiv($rule['virtuemart_calc_id'].'Diff','', $this->cart->pricesUnformatted[$rule['virtuemart_calc_id'].'Diff'],false);?> </td>
		</tr>
		<?php endif;?>
		
		<tr class="sectiontableentry2">
			<td align="right">Amount:</td>
			<td align="right"> <?php echo $this->currencyDisplay->createPriceDiv($rule['virtuemart_calc_id'].'Diff','', $this->cart->pricesUnformatted[$rule['virtuemart_calc_id'].'Diff'],false); ?>  </td>
		</tr>
		<?php
			if($i) $i=1; else $i=0;
		endforeach; // End taxbill rule ?>
		
		<?php
		foreach($this->cart->cartData['taxRulesBill'] as $rule):?>
		<tr class="sectiontableentry<?php $i ?>">
			<td align="right" colspan="2">
				<?php echo $rule['calc_name'] ?> 
			</td>
		</tr>
		<?php if ( VmConfig::get('show_tax')): ?>
		<tr class="sectiontableentry2">
			<td align="right">Tax:</td>
			<td align="right"> <?php echo $this->currencyDisplay->createPriceDiv($rule['virtuemart_calc_id'].'Diff','', $this->cart->pricesUnformatted[$rule['virtuemart_calc_id'].'Diff'],false); ?> </td>
		</tr>
		<?php endif;?>
		
		<tr class="sectiontableentry2">
			<td align="right">Amount:</td>
			<td align="right"><?php echo $this->currencyDisplay->createPriceDiv($rule['virtuemart_calc_id'].'Diff','', $this->cart->pricesUnformatted[$rule['virtuemart_calc_id'].'Diff'],false); ?> </td>
		</tr>
		<?php
			if($i) $i=1; else $i=0;
		endforeach; // End taxRulesBill rule ?>
		
		<?php
		foreach($this->cart->cartData['DATaxRulesBill'] as $rule):?>
		<tr class="sectiontableentry<?php $i ?>">
			<td align="right" colspan="2">
				<?php echo $rule['calc_name'] ?> 
			</td>
		</tr>
		<?php if ( VmConfig::get('show_tax')): ?>
		<tr class="sectiontableentry2">
			<td align="right">Tax:</td>
			<td align="right"><?php echo $this->currencyDisplay->createPriceDiv($rule['virtuemart_calc_id'].'Diff','', $this->cart->pricesUnformatted[$rule['virtuemart_calc_id'].'Diff'],false); ?> </td>
		</tr>
		<?php endif;?>
		
		<tr class="sectiontableentry2">
			<td align="right">Amount:</td>
			<td align="right"><?php echo $this->currencyDisplay->createPriceDiv($rule['virtuemart_calc_id'].'Diff','', $this->cart->pricesUnformatted[$rule['virtuemart_calc_id'].'Diff'],false); ?> </td>
		</tr>
		<?php
			if($i) $i=1; else $i=0;
		endforeach; // End taxRulesBill rule ?>
		
		<!-- automaticSelectedShipment -->
		<?php if (!$this->cart->automaticSelectedShipment){ ?>
		<tr class="sectiontableentry1">
			<td align="left" colspan="2">
				<a name="select-shipping"></a>
				<?php echo $this->cart->cartData['shipmentName']; ?>
				    <br />
				<?php
				if(!empty($this->layoutName) && $this->layoutName=='default' && !$this->cart->automaticSelectedShipment  )
					echo JHTML::_('link', JRoute::_('index.php?view=cart&task=edit_shipment',$this->useXHTML,$this->useSSL), $this->select_shipment_text,' data-role="button" data-inline="true" data-mini="true" ');
				else {
				    JText::_('COM_VIRTUEMART_CART_SHIPPING');
				} ?>
			</td>
		</tr>	
		<?php } else { ?>
		<tr class="sectiontableentry1">
			<td align="right" colspan="2">
				<?php echo $this->cart->cartData['shipmentName']; ?>
			</td>
		</tr>
		<?php } ?>

		<?php if ( VmConfig::get('show_tax')) { ?>
		<tr class="sectiontableentry2">
			<td align="right">Tax:</td>
			<td align="right"><?php echo "<span  class='priceColor2'>".$this->currencyDisplay->createPriceDiv('shipmentTax','', $this->cart->pricesUnformatted['shipmentTax'],false)."</span>"; ?></td>
		</tr>
        <?php } ?>
        <tr class="sectiontableentry2">
        	<td align="right">Amount:</td>
			<td align="right"><?php echo $this->currencyDisplay->createPriceDiv('salesPriceShipment','', $this->cart->pricesUnformatted['salesPriceShipment'],false); ?> </td>
		</tr>
		<!-- End automaticSelectedShipment -->
		
		
		<!-- automaticSelectedPayment -->
        <?php if (!$this->cart->automaticSelectedPayment) { ?>
		<tr class="sectiontableentry1">
			<td align="left" colspan="2">
				<a name="select-payment"></a>
				<?php echo $this->cart->cartData['paymentName']; ?>
				     <br />
				<?php if(!empty($this->layoutName) && $this->layoutName=='default') echo JHTML::_('link', JRoute::_('index.php?view=cart&task=editpayment',$this->useXHTML,$this->useSSL), $this->select_payment_text,' data-role="button" data-inline="true" data-mini="true" '); else JText::_('COM_VIRTUEMART_CART_PAYMENT'); ?>
			</td>
		</tr>
        <?php } else { ?>
        <tr class="sectiontableentry1">
			<td colspan="2" align="left"><?php echo $this->cart->cartData['paymentName']; ?> </td>
		</tr>
		<?php } ?>
		
		<?php if ( VmConfig::get('show_tax')) { ?>
		<tr class="sectiontableentry2">
			<td align="right">Tax:</td>
			<td align="right"><?php echo "<span  class='priceColor2'>".$this->currencyDisplay->createPriceDiv('paymentTax','', $this->cart->pricesUnformatted['paymentTax'],false)."</span>"; ?> </td>
		</tr>
		<?php } ?>
		<tr class="sectiontableentry1">
			<td align="right">Amount: <?php // Why is this commented? what is with payment discounts? echo "<span  class='priceColor2'>".$this->cart->pricesUnformatted['paymentDiscount']."</span>"; ?></td>
			<td align="right"><?php  echo $this->currencyDisplay->createPriceDiv('salesPricePayment','', $this->cart->pricesUnformatted['salesPricePayment'],false); ?> </td>
		</tr>
		<!-- End automaticSelectedPayment -->
		
		<tr class="sectiontableentry1">
			<td colspan="2" align="left"> <hr class="vmhr" /> </td>
		</tr>
		
		<!-- <?php echo JText::_('COM_VIRTUEMART_CART_TOTAL') ?> -->
		<tr class="sectiontableentry1">
			<td colspan="2" align="left"> <?php echo JText::_('COM_VIRTUEMART_CART_TOTAL') ?>: </td>
		</tr>
		<?php if ( VmConfig::get('show_tax')) { ?>
		<tr class="sectiontableentry2">
			<td align="right">Tax:</td>
			<td align="right"> <?php echo "<span  class='priceColor2'>".$this->currencyDisplay->createPriceDiv('billTaxAmount','', $this->cart->pricesUnformatted['billTaxAmount'],false)."</span>" ?> </td>
		</tr>
		<?php } ?>
		<tr class="sectiontableentry1">
			<td align="right">Discount:</td>
			<td align="right"> <?php echo "<span  class='priceColor2'>".$this->currencyDisplay->createPriceDiv('billDiscountAmount','', $this->cart->pricesUnformatted['billDiscountAmount'],false)."</span>" ?> </td>
		</tr>
		
		<tr class="sectiontableentry2">
			<td align="right">Total:</td>
			<td align="right"><strong><?php echo $this->currencyDisplay->createPriceDiv('billTotal','', $this->cart->pricesUnformatted['billTotal'],false); ?></strong></td>
		</tr>
		<!-- End: <?php echo JText::_('COM_VIRTUEMART_CART_TOTAL') ?> -->
		
		
		<?php if ( $this->totalInPaymentCurrency) { ?>
		<tr class="sectiontableentry2">
			<td align="right"><?php echo JText::_('COM_VIRTUEMART_CART_TOTAL_PAYMENT') ?>: </td>
			<td align="right"><strong><?php echo $this->totalInPaymentCurrency;   ?></strong></td>
		</tr>
		<?php } ?>

	</table>
</fieldset>
