<?php
/**
*
* Show the products in a category
*
* @package	VirtueMart
* @subpackage
* @author RolandD
* @author Max Milbers
* @author Nguyen @ MobileMeWs.com
* @todo add pagination
* @link http://www.virtuemart.net
* @copyright Copyright (c) 2004 - 2010 VirtueMart Team. All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
* VirtueMart is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* @version $Id: default.php 2710 2011-02-13 00:51:06Z Electrocity $
*/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');

if ($this->category->haschildren):
?>

<div class="category-view">

<?php // Start the Output
foreach ( $this->category->children as $category ):
	// Category Link
	$caturl = JRoute::_ ( 'index.php?option=com_virtuemart&view=category&virtuemart_category_id=' . $category->virtuemart_category_id );
	// Show Category 
	?>
	<div class="category floatleft">
		<div class="spacer">
			<a href="<?php echo $caturl ?>" title="<?php echo $category->category_name ?>">
				<?php if (!empty($category->images) ) {
					?>
					<span class="image"><?php echo $category->images[0]->displayMediaThumb("",false); ?></span>
					<?php
				} ?>
				<span class="category-name"><?php echo $category->category_name ?></span>
			</a>
		</div>
	</div>
<?php endforeach; ?>
	<div class="clr"></div>
</div>

<?php endif;?>