<?php // no direct access
	defined('_JEXEC') or die('Restricted access');
?>

<div class="mod-manufacture-view">
	<?php if ($headerText) : ?>
	<div class="vmheader"><?php echo $headerText ?></div>
	<?php endif; ?>
	<?php foreach ($manufacturers as $manufacturer): 
		$link = JROUTE::_('index.php?option=com_virtuemart&view=manufacturer&virtuemart_manufacturer_id=' . $manufacturer->virtuemart_manufacturer_id);
	?>
		<div class="mod-manufacture floatleft">
			<div class="spacer">
				<a href="<?php echo $link; ?>">
					<?php
					if ($manufacturer->images && ($show == 'image' or $show == 'all' )) { ?>
						<div class="image"><?php echo $manufacturer->images[0]->displayMediaThumb('',false);?></div>
					<?php
					}
					if ($show == 'text' or $show == 'all' ) { ?>
					 <div class="name"><?php echo $manufacturer->mf_name; ?></div>
					<?php
					} ?>
				</a>
			</div>
		</div>
	<?php endforeach; ?>
	<div class="clr"></div>
	
	<?php if ($footerText) : ?>
	<div class="vmfooter<?php echo $params->get( 'moduleclass_sfx' ) ?>">
		 <?php echo $footerText ?>
	</div>
	<?php endif; ?>
</div>