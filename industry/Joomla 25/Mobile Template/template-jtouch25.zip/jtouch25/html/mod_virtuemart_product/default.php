﻿<?php // no direct access
	defined('_JEXEC') or die('Restricted access');
?>

<div class="vm-listing">
	<?php if ($headerText) { ?>
	<div class="vmheader"><?php echo $headerText ?></div>
	<?php } ?>

	<?php foreach ($products as $product) : 
	$url = JRoute::_('index.php?option=com_virtuemart&view=productdetails&virtuemart_product_id='.$product->virtuemart_product_id.'&virtuemart_category_id='.
										$product->virtuemart_category_id);
	?>
	<div class="product-list">
		<a href="<?php echo $url ?>" title="<?php echo $product->product_name ?>">
			<div class="spacer">
			<?php
				if (!empty($product->images[0]) )
						$image = $product->images[0]->displayMediaThumb('class="featuredProductImage" border="0"',false) ;
				else $image = '';
				?>
				<div class="image">
					<?php echo $image;?>
				</div>
				<div class="intro">
					<div class="name"><?php echo $product->product_name ?></div>
					<div class="description"><?php echo $product->product_s_desc; ?></div>
					
					<?php if ($show_price): ?>
					<div class="product-price">
						<div class="sales-price"><?php echo $currency->createPriceDiv( 'salesPrice', '', $product->prices );?></div>
						
						<?php if ($product->prices['salesPriceWithDiscount']>0): ?>
							<div class="discount-price">(<?php echo JText::_('COM_VIRTUEMART_PRODUCT_DISCOUNT_AMOUNT'); ?> <?php echo $currency->createPriceDiv( 'discountAmount', '', $product->prices );?>)</div>
						<?php endif;?>
						
					</div>
					<?php endif;?>
				</div>
			</div>
		</a>
	</div>
	<?php endforeach; ?>
	<div class="clr"></div>
	
	<?php if ($footerText) : ?>
	<div class="vmfooter<?php echo $params->get( 'moduleclass_sfx' ) ?>">
		 <?php echo $footerText ?>
	</div>
	<?php endif; ?>
	
</div>