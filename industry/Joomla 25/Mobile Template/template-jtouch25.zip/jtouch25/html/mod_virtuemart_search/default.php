<?php // no direct access
defined('_JEXEC') or die('Restricted access'); ?>
<!--BEGIN Search Box -->
<form action="<?php echo JRoute::_('index.php?option=com_virtuemart&view=category&search=true&limitstart=0&virtuemart_category_id='.$category_id ); ?>" method="get" data-ajax="false">
	<fieldset data-role="controlgroup" data-mini="true">
		<input data-mini="true" type="search" name="keyword" id="mod_virtuemart_search" maxlength="<?php echo $maxlength; ?>" 
			onblur="if(this.value=='') this.value='<?php echo $text; ?>';" onfocus="if(this.value=='<?php echo $text; ?>') this.value='';"
			placeholder="<?php echo $text; ?>" />
	</fieldset>	
	<input type="hidden" name="limitstart" value="0" />
	<input type="hidden" name="option" value="com_virtuemart" />
	<input type="hidden" name="view" value="category" />
</form>
<!-- End Search Box -->