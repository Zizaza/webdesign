<?php // no direct access
defined('_JEXEC') or die('Restricted access');
//JHTML::stylesheet ( 'menucss.css', 'modules/mod_virtuemart_category/css/', false );

/* @TODO ID for jQuery dropdown */
?>

<ul data-role="listview" data-inset="true">
	<?php foreach ($categories as $category) {
		$active_menu = 'class="VmClose"';
		$caturl = JRoute::_('index.php?option=com_virtuemart&view=category&virtuemart_category_id='.$category->virtuemart_category_id);
		$cattext = $category->category_name;
		//if ($active_category_id == $category->virtuemart_category_id) $active_menu = 'class="active"';
		if (in_array( $category->virtuemart_category_id, $parentCategories)) $active_menu = 'class="VmOpen"';

		?>

	<li <?php echo $active_menu ?>>
		<?php echo JHTML::link($caturl, $cattext);
		if ($category->childs) {
			?>
			<?php echo JHTML::link($caturl, $cattext); ?>
			<span class="VmArrowdown"> </span>
			<?php
		}
		?>
		<?php if ($category->childs) { ?>
		<ul class="menu<?php echo $class_sfx; ?>" data-role="listview" data-inset="true">
		<?php
			foreach ($category->childs as $child) {
	
			$caturl = JRoute::_('index.php?option=com_virtuemart&view=category&virtuemart_category_id='.$child->virtuemart_category_id);
			$cattext = $child->category_name;
			?>
			<li>
			<?php echo JHTML::link($caturl, $cattext); ?>
			</li>
		<?php } ?>
		</ul>
		<?php } ?>
	</li>
	<?php } ?>
</ul>
