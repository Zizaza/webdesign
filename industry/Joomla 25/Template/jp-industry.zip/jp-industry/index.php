<?php 
/**
 * @license Commercial/Proprietery - released under a commercial license
 * design by: Joomlaplates
 */
defined('_JEXEC') or die;

/* The following line loads the MooTools JavaScript Library */
JHtml::_('behavior.framework', true);

/* The following line gets the application object for things like displaying the site name */
$app = JFactory::getApplication();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>" >
<head>
<jdoc:include type="head" />

<link rel="stylesheet" href="<?php echo $this->baseurl; ?>/templates/system/css/general.css" type="text/css" />
<!-- Loads Template Layout CSS -->
<link rel="stylesheet" href="templates/<?php echo $this->template ?>/css/layout.css" type="text/css" />
<!-- Loads Joomla base/default classes-->	
<link rel="stylesheet" href="templates/<?php echo $this->template ?>/css/template.css" type="text/css" />
<!-- Loads left main right -->	
<link rel="stylesheet" href="templates/<?php echo $this->template ?>/css/<?php echo $this->params->get('template_layout'); ?>.css" type="text/css"/>
<!-- Loads menu-->	
<link rel="stylesheet" href="templates/<?php echo $this->template ?>/css/menu.css" type="text/css" />
<!-- Loads Suckerfish -->	
<link rel="stylesheet" href="templates/<?php echo $this->template ?>/css/suckerfish.css" type="text/css"/>
<!-- Loads Module Styles -->	
<link rel="stylesheet" href="templates/<?php echo $this->template ?>/css/module.css" type="text/css" />
<!-- Loads CSS3 Styles -->	
<link rel="stylesheet" href="templates/<?php echo $this->template ?>/css/css3.css" type="text/css" />
<!-- Loads Typo -->	
<link rel="stylesheet" href="templates/<?php echo $this->template ?>/css/jp_typo.css" type="text/css" />
<!-- Loads Color Styles -->	
<link rel="stylesheet" href="templates/<?php echo $this->template ?>/css/background/<?php echo $this->params->get('background'); ?>.css" type="text/css"/>
<!--[if IE 8]>
<link rel="stylesheet" href="templates/<?php echo $this->template ?>/css/css3_off.css" type="text/css" media="screen, projection, print">
<![endif]-->
<?php if($this->params->get('k2') == 1) : ?>
<!-- Loads K2 Styles -->
<link rel="stylesheet" href="templates/<?php echo $this->template ?>/css/k2.css" type="text/css" />
<?php endif; ?>
<?php if($this->params->get('custom') == 1) : ?>
<!-- Loads Custom Styles -->
<link rel="stylesheet" href="templates/<?php echo $this->template ?>/css/custom.css" type="text/css" />
<?php endif; ?>

<!-- Loads Template Parameter -->	
<?php require_once('includes/parameter.php'); ?>
<!--Loads FavIcon-->
<link rel="shortcut icon" href="<?php echo $this->baseurl;?>/templates/<?php echo $this->template ?>/images/favicon.ico" />  
</head>
<body style="font-size:<?php echo $this->params->get('body-font-size'); ?>;">
<!--LOGO & SUCKERFISH -->
<div class="top-outer">
	<div class="top-inner template_width">
		<a href="<?php echo $this->baseurl;?>"><img class="logo" src="<?php echo $this->params->get('logo'); ?>" alt="<?php echo $app->getCfg('sitename'); ?>"  /></a>
		<!--BEGINN SUCKERFISH -->
		<?php if($this->countModules('suckerfish')) : ?><div id="suckerfish" class="dropdown"><jdoc:include type="modules" name="suckerfish" style="raw" /></div><?php endif; ?>
		<!--END SUCKERFISH -->
		<div class="jpclear"></div>
	</div>
</div>
<!--END LOGO & SUCKERFISH -->
<!--BREADCRUMBS & SEARCH -->
<div class="pathway-outer">
	<div class="pathway-inner template_width">
	<?php if($this->countModules('breadcrumbs')) : ?><div class="jppathway"><jdoc:include type="modules" name="breadcrumbs" style="raw" /></div><?php endif; ?>
	<?php if($this->countModules('search')) : ?><div class="jpsearch"><jdoc:include type="modules" name="search" style="raw" /></div><?php endif; ?>
	</div>
	<div class="jpclear"></div>
</div>
<!--END BREADCRUMBS & SEARCH -->
<div class="pathway-shadow"></div>

<!--SLIDESHOW -->
	<?php if($this->countModules('slideshow-1')) : ?>
		<div class="slideshow-1 template_width"><jdoc:include type="modules" name="slideshow-1" style="xhtml" /></div>
		<div class="jpclear"></div>		
	<?php endif; ?>
 <!-- END SLIDESHOW-->

<!--MAINAREA -->
	  <div class="main template_width">
		<div class="container">
		<!--SLIDESHOW 2-->
			<?php if($this->countModules('slideshow-2')) : ?>
				<div class="slideshow-2"><jdoc:include type="modules" name="slideshow-2" style="xhtml" /></div>
				<div class="slideshow-shadow"></div>		
				<div class="jpclear"></div>		
			<?php endif; ?>
		 <!-- END SLIDESHOW 2 -->

	<!-- ****************** Top Area ****************** -->
	<?php if($this->countModules('top100 or top25-1 or top25-2 or top25-3 or top25-4 or top33-1 or top33-2 or top33-3 or top50-1 or top50-2 or top66-1 or top66-2')) : ?> 	
		<div class="jp_top_module"><?php require_once('includes/top.php'); ?></div><?php endif; ?>	
	<!-- ****************** End Top Area ****************** -->
		<!-- Including inner content area -->
		<?php require_once('includes/innercontent.php'); ?>
		<!-- ****************** Bottom Area ****************** -->
	<?php if($this->countModules('bottom25-1 or bottom25-2 or bottom25-3 or bottom25-4 or bottom50-1 or bottom50-2 or bottom33-1 or bottom33-2 or bottom33-3 or bottom66-1 or bottom66-2')) : ?> 
	<div class="jp_bottom_module"><?php require_once('includes/bottom.php'); ?></div>
	<?php endif; ?>
</div>
</div>
	<div class="jpclear"></div><!--AUTO HEIGH FIX FOR FIREFOX -->

<!-- ****************** Footer Area ****************** -->
		<?php if($this->countModules('footer-1 or footer-2 or footer-3 or footer-4 or footer-5')) : ?> 
		<div class="jp_footer_module_outer">
			<div class="jp_footer_module template_width"><?php require_once('includes/footer.php'); ?></div>
		<div class="jpclear"></div><!--AUTO HEIGH FIX FOR FIREFOX -->
		</div>
		<?php endif; ?>

<!-- ****************** Legalline  ****************** -->
		<?php if($this->countModules('footer')) : ?>
			<div class="legaline">
				<jdoc:include type="modules" name="footer" style="xhtml" />	
			</div>
			<div class="jpclear"></div>		
		<?php endif; ?>
		
 <!-- div.Legalline ends here-->
	

<jdoc:include type="modules" name="debug" style="raw" />


</body>
</html>