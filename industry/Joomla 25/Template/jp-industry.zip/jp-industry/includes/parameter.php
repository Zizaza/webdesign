<?php 
/**
 * @license Commercial/Proprietery - released under a commercial license
 * design by: Joomlaplates
 */
defined('_JEXEC') or die;
?>

<!--Slimbox Parameter -->
<?php if($this->params->get('slimbox') == 1) : ?>
<script type="text/javascript" src="templates/<?php echo $this->template ?>/js/slimbox.js"></script>
<?php endif; ?>

<style type="text/css" media="screen">
body{font-family:<?php echo $this->params->get('font-type'); ?>,Arial, Helvetica, sans-serif}
</style>

<!--Google Fonts Parameters -->
<?php if($this->params->get('google') == 1) : ?>
<link href="<?php echo $this->params->get('google-url'); ?>" rel="stylesheet" type="text/css"/>
<?php if($this->params->get('google-h3') == 1) : ?>
<style type="text/css" media="screen">
h3,h2,h2 a{font-family:<?php echo $this->params->get('google-font'); ?>,Arial, Helvetica, sans-serif}
</style>
<?php endif; ?>
<?php if($this->params->get('google-h3') == 0) : ?>
<style type="text/css" media="screen">
body{font-family:<?php echo $this->params->get('google-font'); ?>,Arial, Helvetica, sans-serif}
</style>
<?php endif; ?>
<?php endif; ?>

<style type="text/css" media="screen">
/*Left and Right Module Width */
#left, #right  { width:<?php echo $this->params->get('module_width'); ?>; }
/*Template Width*/
.template_width { width:<?php echo $this->params->get('template_width'); ?>; }
/*Font Settings*/
h2, h2 a{color:<?php echo $this->params->get('content_header_color'); ?>;}
.jp_top_module h3, .jp_bottom_module h3,#right h3, #left h3, h3 {color:<?php echo $this->params->get('module_header_color'); ?>;}
.moduletable h3, .module h3 { font-size:<?php echo $this->params->get('module-headline-font-size'); ?>!important;}
h2, h2 a { font-size:<?php echo $this->params->get('content-headline-font-size'); ?>!important;}
/* Logo Settings*/
.logo{width:<?php echo $this->params->get('logo_width'); ?>;height:<?php echo $this->params->get('logo_height'); ?>}
#suckerfish li a {height:<?php echo $this->params->get('logo_height'); ?>;line-height:<?php echo $this->params->get('logo_height'); ?>;}
/* Template Color Settings*/
.pathway-outer{ background-color:<?php echo $this->params->get('pathway-bg'); ?>}
#suckerfish li.active a{background:<?php echo $this->params->get('pathway-bg'); ?>; color:<?php echo $this->params->get('pathway-color'); ?>;}
.jp_footer_module_outer{background:<?php echo $this->params->get('pathway-bg'); ?>; color:<?php echo $this->params->get('pathway-color'); ?>;}
.jp_footer_module_outer h3,.jp_footer_module_outer a {background:<?php echo $this->params->get('pathway-bg'); ?>; color:<?php echo $this->params->get('pathway-color'); ?>;}
.jp_footer_module div.moduletable h3{border-bottom:1px solid <?php echo $this->params->get('pathway-color'); ?>}
.readmore a, .readon, .button{background:<?php echo $this->params->get('pathway-bg'); ?>;color:<?php echo $this->params->get('pathway-color'); ?>;padding:4px 10px}
/* Custom Module Styles */
div.module.color h3{padding:6px 0 6px 0px!important;margin:0;color:<?php echo $this->params->get('pathway-color'); ?>!important;text-transform:uppercase;border-bottom:1px solid <?php echo $this->params->get('pathway-color'); ?>!important}
div.module.color{padding:20px!important;margin:0;background:<?php echo $this->params->get('pathway-bg'); ?>;color:<?php echo $this->params->get('pathway-color'); ?>}
div.module.color a {color:<?php echo $this->params->get('pathway-color'); ?>!important}
div.module.color a:hover {color:<?php echo $this->params->get('pathway-color'); ?>!important}

</style>

<!--Starting Suckerfish Script-->
<?php if($this->params->get('showSuckerfish') == 1) : ?>
<script type="text/javascript" src="<?php echo $this->baseurl;?>/templates/<?php echo $this->template ?>/js/moomenu.js"></script>
<script type="text/javascript">
window.addEvent('domready',function(){
	$('suckerfish').MooDropMenu({
		onOpen: function(el){
			el.fade('in')
		},
		onClose: function(el){
			el.fade('out');
		},
		onInitialize: function(el){
			el.fade('hide').set('tween',{duration:500});
		}
	});

});
</script>
<?php endif; ?>
<!--Suckerfish Script End-->


