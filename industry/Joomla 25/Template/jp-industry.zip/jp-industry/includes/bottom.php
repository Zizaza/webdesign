	
		<!-- Bottom Content Area -->
		<div class="block0 bottom_content">
			
		<!--Two Blocks one with 66% and one with 33%-->
		<?php if($this->countModules('bottom66-1')) : ?>
			<div class="block23 bottom66-1">
				<jdoc:include type="modules" name="bottom66-1" style="xhtml" />
			</div>
		<?php endif; ?>	
			
		<?php if($this->countModules('bottom66-2')) : ?>
			<div class="block3 bottom66-2 lastblock">
				<jdoc:include type="modules" name="bottom66-2" style="xhtml" />
			</div>
		<?php endif; ?>	
		<?php if($this->countModules('bottom66-1 or bottom66-2')) : ?> 
			<hr />
		<?php endif; ?>
			
		<!--Two 50% Blocks-->
		<?php if($this->countModules('bottom50-1')) : ?>
			<div class="block2 bottom50-1">
				<jdoc:include type="modules" name="bottom50-1" style="xhtml" />
			</div>
		<?php endif; ?>	
			
		<?php if($this->countModules('bottom50-2')) : ?>
			<div class="block2 bottom50-2 lastblock">
				<jdoc:include type="modules" name="bottom50-2" style="xhtml" />
			</div>
		<?php endif; ?>	
		<?php if($this->countModules('bottom50-1 or bottom50-2')) : ?> 
			<hr />
		<?php endif; ?>

		<!--Three 33% Blocks-->
		<?php if($this->countModules('bottom33-1')) : ?>
			<div class="block3 bottom33-1">
				<jdoc:include type="modules" name="bottom33-1" style="xhtml" />
			</div>
		<?php endif; ?>
		
		<?php if($this->countModules('bottom33-2')) : ?>
			<div class="block3 bottom33-2">
				<jdoc:include type="modules" name="bottom33-2" style="xhtml" />
			</div>
		<?php endif; ?>
		
		<?php if($this->countModules('bottom33-3')) : ?>
			<div class="block3 bottom33-3 lastblock">
				<jdoc:include type="modules" name="bottom33-3" style="xhtml" />
			</div>
		<?php endif; ?>
		
		<?php if($this->countModules('bottom33-1 or bottom33-2 or bottom33-3')) : ?> 
			<hr />
		<?php endif; ?>
			
		<!--Four 25% Blocks-->
		<?php if($this->countModules('bottom25-1')) : ?>
			<div class="block4 bottom25-1">
				<jdoc:include type="modules" name="bottom25-1" style="xhtml" />
			</div>
		<?php endif; ?> 
		
		<?php if($this->countModules('bottom25-2')) : ?>
			<div class="block4 bottom25-2">
				<jdoc:include type="modules" name="bottom25-2" style="xhtml" />
			</div>
		<?php endif; ?> 
		
		<?php if($this->countModules('bottom25-3')) : ?>
			<div class="block4">
				<jdoc:include type="modules" name="bottom25-3" style="xhtml" />
			</div>
		<?php endif; ?>
		
		<?php if($this->countModules('bottom25-4')) : ?>
			<div class="block4 bottom25-4 lastblock">
				<jdoc:include type="modules" name="bottom25-4" style="xhtml" />
			</div>
		<?php endif; ?>
		
		<?php if($this->countModules('bottom25-1 or bottom25-2 or bottom25-3 or bottom25-4')) : ?> 
			<hr />
		<?php endif; ?>
		</div>


