	<div class="footer">
		
		<!--Five 20% Blocks-->
		<?php if($this->countModules('footer-1')) : ?>
			<div class="block5 footer-1">
				<jdoc:include type="modules" name="footer-1" style="xhtml" />
			</div>
		<?php endif; ?>			
		
		<?php if($this->countModules('footer-2')) : ?>
			<div class="block5 footer-2">
				<jdoc:include type="modules" name="footer-2" style="xhtml" />
			</div>
		<?php endif; ?>	
		
		<?php if($this->countModules('footer-3')) : ?>
			<div class="block5 footer-3">
				<jdoc:include type="modules" name="footer-3" style="xhtml" />
			</div>
		<?php endif; ?>	
		
		<?php if($this->countModules('footer-4')) : ?>
			<div class="block5 footer-4">
				<jdoc:include type="modules" name="footer-4" style="xhtml" />
			</div>
		<?php endif; ?>
		
		<?php if($this->countModules('footer-5')) : ?>
			<div class="block5 footer-5 lastblock">
				<jdoc:include type="modules" name="footer-5" style="xhtml" />
			</div>
		<?php endif; ?>
			<hr />
		</div>
