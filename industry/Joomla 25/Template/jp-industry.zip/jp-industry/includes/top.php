
		<!-- Top Content Area -->
		<div class="block0 top_content">
		<!--Four 25% Blocks-->
		<?php if($this->countModules('top25-1')) : ?>
			<div class="block4 top25-1">
				<jdoc:include type="modules" name="top25-1" style="xhtml" />
			</div>
		<?php endif; ?> 
		
		<?php if($this->countModules('top25-2')) : ?>
			<div class="block4 top25-2">
				<jdoc:include type="modules" name="top25-2" style="xhtml" />
			</div>
		<?php endif; ?> 
		
		<?php if($this->countModules('top25-3')) : ?>
			<div class="block4 top25-3">
				<jdoc:include type="modules" name="top25-3" style="xhtml" />
			</div>
		<?php endif; ?>
		
		<?php if($this->countModules('top25-4')) : ?>
			<div class="block4 top25-4 lastblock">
				<jdoc:include type="modules" name="top25-4" style="xhtml" />
			</div>
		<?php endif; ?>
		
		<?php if($this->countModules('top25-1 or top25-2 or top25-3 or top25-4')) : ?> 
		  <hr />
		<?php endif; ?>
		
		<!--Three 33% Blocks-->
		<?php if($this->countModules('top33-1')) : ?>
			<div class="block3 top33-1">
				<jdoc:include type="modules" name="top33-1" style="xhtml" />
			</div>
		<?php endif; ?>
		
		<?php if($this->countModules('top33-2')) : ?>
			<div class="block3 top33-2">
				<jdoc:include type="modules" name="top33-2" style="xhtml" />
			</div>
		<?php endif; ?>
		
			<?php if($this->countModules('top33-3')) : ?>
			<div class="block3 top33-3 lastblock">
				<jdoc:include type="modules" name="top33-3" style="xhtml" />
			</div>
		<?php endif; ?>
		
		<?php if($this->countModules('top33-1 or top33-2 or top33-3')) : ?> 
			<hr />
		<?php endif; ?>
			
		<!--Two 50% Blocks-->
		<?php if($this->countModules('top50-1')) : ?>
			<div class="block2 top50-1">
				<jdoc:include type="modules" name="top50-1" style="xhtml" />
			</div>
		<?php endif; ?>	
			
		<?php if($this->countModules('top50-2')) : ?>
			<div class="block2 top50-2 lastblock">
				<jdoc:include type="modules" name="top50-2" style="xhtml" />
			</div>
		<?php endif; ?>	
		<?php if($this->countModules('top50-1 or top50-2')) : ?> 
			<hr />
		<?php endif; ?>

		
		<!--Two Blocks one with 66% and one with 33%-->
		<?php if($this->countModules('top66-1')) : ?>
			<div class="block23 top66-1">
				<jdoc:include type="modules" name="top66-1" style="xhtml" />
			</div>
		<?php endif; ?>	
			
		<?php if($this->countModules('top66-2')) : ?>
			<div class="block3 top66-2 lastblock">
				<jdoc:include type="modules" name="top66-2" style="xhtml" />
			</div>
		<?php endif; ?>	
		<?php if($this->countModules('top66-1 or top66-2')) : ?> 
			<hr />
		<?php endif; ?>
		</div>
	