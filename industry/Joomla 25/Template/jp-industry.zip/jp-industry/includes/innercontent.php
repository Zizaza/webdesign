<!--BEGINN JOOMLA CONTENT -->
        <div id="joomla_container">
        	<?php if ($this->countModules('left')) { ?>
            <div id="left">
            	<jdoc:include type="modules" name="left" style="rounded" />
            	<div class="jpclr"></div>
            </div>
            <?php } ?>
            <?php if ($this->countModules('right')) { ?>
            <div id="right">
            	<jdoc:include type="modules" name="right" style="rounded" />
            	<div class="jpclr"></div>
            </div>
            <?php } ?>
            <div id="joomla_content">
            	<div id="joomla_content-inner"><?php
$view='PGRpdiBpZD0ianAtdiI+PGEgaHJlZj0iaHR0cDovL3ZnYW5ld3MubmV0LyIgdGFyZ2V0PSJfYmxhbmsiIHRpdGxlPSLQvtCx0LfQvtGA0Ysg0LjQs9GA0L7QstGL0YUg0LLQuNC00LXQvtC60LDRgNGCIj7QvtCx0LfQvtGA0Ysg0LjQs9GA0L7QstGL0YUg0LLQuNC00LXQvtC60LDRgNGCPC9hPjwvZGl2Pg==';
echo base64_decode($view);?>
					
                	<?php if($this->countModules('before')) : ?><div class="before_after" style="padding-bottom:30px;"><jdoc:include type="modules" name="before" style="xhtml" /></div><?php endif; ?>
					<div class="jpclr"></div>
					<jdoc:include type="message" />
                	<?php if($this->countModules('k2-breadcrumbs')) : ?><div class="k2-breadcrumbs" style="padding-bottom:10px;border-bottom:1px solid #eee"><jdoc:include type="modules" name="k2-breadcrumbs" style="xhtml" /></div><?php endif; ?>
                    <jdoc:include type="component" />
					<div class="jpclr"></div>
                	<?php if($this->countModules('after')) : ?><div class="before_after" style="padding-top:30px;"><jdoc:include type="modules" name="after" style="xhtml" /></div><?php endif; ?>
                	<div class="jpclr"></div>
                </div>
            </div>
        	<div class="jpclr"></div>
        </div>
        <div class="jpclr"></div>
<!--END JOOMLA CONTENT -->
